# Freeplug merch wordmark variants — casual-game pop with red plate

Updated 11 November 2026, America/Chicago (8:16 AM CT). Cheke asked to thin the uncurly lettering and change the pale letter backlay to black. v1 plated pop files are in `before/pop-plate-v1/`. Cursive plate files were not rebuilt.
Print files only. Repo, Printify, and the site were not modified.

## Plate

The plate is the original plain-item rounded rectangle: **1410 × 405 on a 1500 × 525 canvas, rx=35**, scaled and **sized to wrap each wordmark** with the same padding feel as the source "Freeplug" print (text inset 6.0% of plate width, 12.6% of plate height). Aspect 1410:405 and rx/height = 35/405 are held constant. The longest mark fills (or nearly fills) the original plate size of 4230 × 1215 on the 4500 × 1575 main canvas; shorter marks get a smaller, hugging plate, centered.

**Plate color: Freeplug Red `#8B1A1E`.** Ivory `#f7f3ea` lettering sits on the plate (8.37:1). Ink `#171717` on this plate is only 1.93:1, and ink on the old merch red `#ba3d3d` is only 3.26:1, so both were rejected for the lettering.

- `*-dark` (light items): plate only. The plate edge already passes 3:1 on white (9.27:1) and natural (6.94:1).
- `*-light` (dark items): the same plate and lettering, plus a thin ivory `#f7f3ea` ring around the plate (6 px on the 1500 source, scaled with plate height; rx grows with the ring so the offset is uniform). The bare plate fails 3:1 on black (2.26:1) and charcoal (1.19:1); the ivory ring is 18.96:1 on black and 9.94:1 on charcoal.
- Transparent outside the plate (and ring, when present). No extra background.

## Lettering

The casual-game pop balloon lettering is kept (bounce, gloss, geometric FPLGN L) but v2 is 30% thinner (pen 156→109, outline 78→54.6, extrusion 48→33.6). Letter faces stay ivory `#f7f3ea`; the outline and extrusion (the letter backlay) are ink `#171717`. Dark-item files still have the thin ivory ring around the plate, not around the letters. Ivory face vs black outline is 16.19:1; ivory face vs the plate is 8.37:1. The black outline against the plate is only 1.93:1 (a quiet rim), which is reported below.

## Canvas ratios

- **Main (20:7)** — `4500 × 1575` px. Files at the folder root.
- **Square (1:1)** — `4500 × 4500` px, same badge as main, centered. Subfolder `square/`.
- **Portrait (3:4)** — `4500 × 6000` px, same badge as main, centered. Subfolder `portrait/`.
- **Bar (6.5:1)** — `4500 × 692` px, badge scaled to fit. Subfolder `bar/`.

Mapping is the same as the unplated sets: main files for the 267 baked plain SKUs (including the 195 buyer-shop items); `square/` for fanny-pack-468, glass-cutting-board-938, garden-house-banner-976; `portrait/` for the two matte canvases and metal-art-sign-1206; `bar/` for the bracelet engraving aspect.

## Contrast (WCAG relative luminance)

Text on the plate must be ≥4.5:1. The plate edge (or the ivory ring, on dark items) must be ≥3:1 against the garment.

| Pair | Ratio | Result |
|---|---|---|
| ivory #f7f3ea face on plate #8B1A1E (text, 4.5) | 8.37:1 | PASS |
| ivory #f7f3ea face vs black outline #171717 (text, 4.5) | 16.19:1 | PASS |
| black outline #171717 vs plate #8B1A1E (reported; not the required face contrast) | 1.93:1 | FAIL |
| cream face #d6c6b0 on plate #8B1A1E (pop bevel floor, 4.5) | 5.55:1 | PASS |
| cream deep #d0bea8 on plate #8B1A1E (pop bevel, 4.5) | 5.13:1 | PASS |
| white gloss on plate #8B1A1E (4.5) | 9.27:1 | PASS |
| (rejected) ink #171717 on plate #8B1A1E | 1.93:1 | FAIL |
| plate #8B1A1E vs white (edge, 3.0) — light items, no ring | 9.27:1 | PASS |
| plate #8B1A1E vs natural (232,222,200) (edge, 3.0) | 6.94:1 | PASS |
| plate #8B1A1E vs black (edge, 3.0) — fails, ring required | 2.26:1 | FAIL |
| plate #8B1A1E vs charcoal (60,60,62) (edge, 3.0) — fails, ring required | 1.19:1 | FAIL |
| ivory ring #f7f3ea vs black (edge, 3.0) — dark items | 18.96:1 | PASS |
| ivory ring #f7f3ea vs charcoal (edge, 3.0) — dark items | 9.94:1 | PASS |
| (reference) old merch red #ba3d3d vs natural (edge, 3.0) | 4.11:1 | PASS |
| (reference) ink #171717 on old merch red #ba3d3d (text, 4.5) | 3.26:1 | FAIL |

Pop red fills (`#e83e36`, mid `#be2426`) on plate `#8B1A1E` are only 2.28:1 and 1.53:1, so the pop files keep the balloon construction, bounce, extrusion, bevel and gloss, but use ivory faces and ivory outlines. Cursive files use the same FP Cursive Bold construction as the unplated set, in ivory.

## Files

Naming: `<slug>-<light|dark>.png` / `.svg`. `light` = dark items (ivory ring). `dark` = light items (plate only). SVGs are paths plus the plate rect (no live text).

- `overview.png`
- `freeplug-dev-dark.png`
- `freeplug-dev-dark.svg`
- `square/freeplug-dev-dark.png`
- `square/freeplug-dev-dark.svg`
- `portrait/freeplug-dev-dark.png`
- `portrait/freeplug-dev-dark.svg`
- `freeplug-dev-light.png`
- `freeplug-dev-light.svg`
- `square/freeplug-dev-light.png`
- `square/freeplug-dev-light.svg`
- `portrait/freeplug-dev-light.png`
- `portrait/freeplug-dev-light.svg`
- `bar/freeplug-dev-dark.png`
- `bar/freeplug-dev-dark.svg`
- `bar/freeplug-dev-light.png`
- `bar/freeplug-dev-light.svg`
- `fplgn-dark.png`
- `fplgn-dark.svg`
- `square/fplgn-dark.png`
- `square/fplgn-dark.svg`
- `portrait/fplgn-dark.png`
- `portrait/fplgn-dark.svg`
- `fplgn-light.png`
- `fplgn-light.svg`
- `square/fplgn-light.png`
- `square/fplgn-light.svg`
- `portrait/fplgn-light.png`
- `portrait/fplgn-light.svg`
- `bar/fplgn-dark.png`
- `bar/fplgn-dark.svg`
- `bar/fplgn-light.png`
- `bar/fplgn-light.svg`
- `freeplug-in-dev-dark.png`
- `freeplug-in-dev-dark.svg`
- `square/freeplug-in-dev-dark.png`
- `square/freeplug-in-dev-dark.svg`
- `portrait/freeplug-in-dev-dark.png`
- `portrait/freeplug-in-dev-dark.svg`
- `freeplug-in-dev-light.png`
- `freeplug-in-dev-light.svg`
- `square/freeplug-in-dev-light.png`
- `square/freeplug-in-dev-light.svg`
- `portrait/freeplug-in-dev-light.png`
- `portrait/freeplug-in-dev-light.svg`
- `bar/freeplug-in-dev-dark.png`
- `bar/freeplug-in-dev-dark.svg`
- `bar/freeplug-in-dev-light.png`
- `bar/freeplug-in-dev-light.svg`
- `freeplug-in-dark.png`
- `freeplug-in-dark.svg`
- `square/freeplug-in-dark.png`
- `square/freeplug-in-dark.svg`
- `portrait/freeplug-in-dark.png`
- `portrait/freeplug-in-dark.svg`
- `freeplug-in-light.png`
- `freeplug-in-light.svg`
- `square/freeplug-in-light.png`
- `square/freeplug-in-light.svg`
- `portrait/freeplug-in-light.png`
- `portrait/freeplug-in-light.svg`
- `bar/freeplug-in-dark.png`
- `bar/freeplug-in-dark.svg`
- `bar/freeplug-in-light.png`
- `bar/freeplug-in-light.svg`

Overview: `overview.png`.

## Rebuild

```sh
python3 /workspace/logos/freeplug-merchandise/build_wordmark_plates.py
```

