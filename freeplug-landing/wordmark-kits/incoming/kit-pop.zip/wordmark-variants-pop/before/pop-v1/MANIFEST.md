# Freeplug merch wordmark variants — casual-game pop title

Built 11 November 2026, America/Chicago. Cheke review of the cursive overview, 3:20 AM CT: restyle in a bright casual-game title style. Earlier cursive set at `../wordmark-variants/` is kept untouched as an alternative.
Print files only. Repo, Printify, and the site were not modified.

## Style

Original balloon lettering drawn as centerlines and inflated with a round pen (the same construction idea as the Freeplug type families, but a new chubby display alphabet just for these titles). It is inspired by casual-puzzle-game title art as a genre — chunky rounded letters, a thick contrasting outline, a short solid extrusion, a glossy top-left highlight and a darker bevel, a slight bounce/arch — and is not a copy of any existing game logo.

- Palette is anchored on Freeplug Red `#8B1A1E`, with a punchy lighter red at the top of the fill, ivory `#f7f3ea` highlights, and ink `#171717`.
- Light-items files (`*-dark`): outermost outline and extrusion in ink `#171717`.
- Dark-items files (`*-light`): outermost outline and extrusion in ivory `#f7f3ea`.
- No background plate; canvas is transparent outside the letters.
- FPLGN uses a geometric capital L (vertical stem + long horizontal foot) so it cannot be read as a 2. Ligatures are not used; each letter is its own path.
- One typographic size is shared across the four versions, fitted so `Freeplug-in.dev` (with outline and extrusion) has 8.63% side padding on the main 20:7 canvas. Shorter marks are centered at that size, with a gentle arch and follow-the-arc rotation.

Lettering is original to this job (not FP Cursive, not FP Extended, not a third-party display face).

## Canvas ratios

- **Main (20:7)** — `4500 × 1575` px. Scale 0.64934555. Files at the folder root.
- **Square (1:1)** — `4500 × 4500` px, same letter size as main, centered. Subfolder `square/`.
- **Portrait (3:4)** — `4500 × 6000` px, same letter size as main, centered. Subfolder `portrait/`.
- **Bar (6.5:1)** — `4500 × 692` px, scale 0.39871106. Subfolder `bar/`.

Mapping is the same as the cursive set: main files for the 267 baked plain SKUs; `square/` for fanny-pack-468, glass-cutting-board-938, garden-house-banner-976; `portrait/` for the two matte canvases and metal-art-sign-1206; `bar/` for the bracelet engraving aspect (the live engraving remains a different, Extended Black style). The PR #59 CSV has no print-area columns; this mapping is inferred from the 1500×525 shop asset and coming-soon-7 print specs.

## Contrast (WCAG relative luminance)

Required: the outermost edge hits at least 4.5:1 against white and natural for the ink-outline (light-items) files, and against black and charcoal for the ivory-outline (dark-items) files. Fill-to-garment ratios are reported as well; the fill is a red gradient so some fill-to-dark-garment values fall short, which is why the ivory outline is the contrast edge on dark items.

| Pair | Ratio | Result |
|---|---|---|
| outer edge ink #171717 vs white (light-items / *-dark) | 17.93:1 | PASS |
| outer edge ink #171717 vs natural (232,222,200) | 13.41:1 | PASS |
| outer edge ivory #f7f3ea vs black (dark-items / *-light) | 18.96:1 | PASS |
| outer edge ivory #f7f3ea vs charcoal (60,60,62) | 9.94:1 | PASS |
| fill highlight #e83e36 vs white | 4.06:1 | FAIL |
| fill highlight #e83e36 vs natural | 3.04:1 | FAIL |
| fill highlight #e83e36 vs black | 5.17:1 | PASS |
| fill highlight #e83e36 vs charcoal | 2.71:1 | FAIL |
| fill mid #be2426 vs white | 6.05:1 | PASS |
| fill mid #be2426 vs natural | 4.53:1 | PASS |
| fill mid #be2426 vs black | 3.47:1 | FAIL |
| fill mid #be2426 vs charcoal | 1.82:1 | FAIL |
| fill base Freeplug Red #8B1A1E vs white | 9.27:1 | PASS |
| fill base Freeplug Red #8B1A1E vs natural | 6.94:1 | PASS |
| fill base Freeplug Red #8B1A1E vs black | 2.26:1 | FAIL |
| fill base Freeplug Red #8B1A1E vs charcoal | 1.19:1 | FAIL |

## Files

Naming: `<slug>-<light|dark>.png` / `.svg`. `light` = ivory outline (dark items). `dark` = ink outline (light items). SVGs are paths only (no live text).

- `overview.png`
- `freeplug-dev-dark.png`
- `freeplug-dev-dark.svg`
- `freeplug-dev-light.png`
- `freeplug-dev-light.svg`
- `fplgn-dark.png`
- `fplgn-dark.svg`
- `fplgn-light.png`
- `fplgn-light.svg`
- `freeplug-in-dev-dark.png`
- `freeplug-in-dev-dark.svg`
- `freeplug-in-dev-light.png`
- `freeplug-in-dev-light.svg`
- `freeplug-in-dark.png`
- `freeplug-in-dark.svg`
- `freeplug-in-light.png`
- `freeplug-in-light.svg`
- `square/freeplug-dev-dark.png`
- `square/freeplug-dev-dark.svg`
- `square/freeplug-dev-light.png`
- `square/freeplug-dev-light.svg`
- `square/fplgn-dark.png`
- `square/fplgn-dark.svg`
- `square/fplgn-light.png`
- `square/fplgn-light.svg`
- `square/freeplug-in-dev-dark.png`
- `square/freeplug-in-dev-dark.svg`
- `square/freeplug-in-dev-light.png`
- `square/freeplug-in-dev-light.svg`
- `square/freeplug-in-dark.png`
- `square/freeplug-in-dark.svg`
- `square/freeplug-in-light.png`
- `square/freeplug-in-light.svg`
- `portrait/freeplug-dev-dark.png`
- `portrait/freeplug-dev-dark.svg`
- `portrait/freeplug-dev-light.png`
- `portrait/freeplug-dev-light.svg`
- `portrait/fplgn-dark.png`
- `portrait/fplgn-dark.svg`
- `portrait/fplgn-light.png`
- `portrait/fplgn-light.svg`
- `portrait/freeplug-in-dev-dark.png`
- `portrait/freeplug-in-dev-dark.svg`
- `portrait/freeplug-in-dev-light.png`
- `portrait/freeplug-in-dev-light.svg`
- `portrait/freeplug-in-dark.png`
- `portrait/freeplug-in-dark.svg`
- `portrait/freeplug-in-light.png`
- `portrait/freeplug-in-light.svg`
- `bar/freeplug-dev-dark.png`
- `bar/freeplug-dev-dark.svg`
- `bar/freeplug-dev-light.png`
- `bar/freeplug-dev-light.svg`
- `bar/fplgn-dark.png`
- `bar/fplgn-dark.svg`
- `bar/fplgn-light.png`
- `bar/fplgn-light.svg`
- `bar/freeplug-in-dev-dark.png`
- `bar/freeplug-in-dev-dark.svg`
- `bar/freeplug-in-dev-light.png`
- `bar/freeplug-in-dev-light.svg`
- `bar/freeplug-in-dark.png`
- `bar/freeplug-in-dark.svg`
- `bar/freeplug-in-light.png`
- `bar/freeplug-in-light.svg`

Overview: `overview.png` — all 4 versions × ink outline on white and natural, ivory outline on charcoal and black.

## Rebuild

```sh
python3 /workspace/logos/freeplug-merchandise/wordmark-variants-pop/build_wordmark_variants_pop.py
```

