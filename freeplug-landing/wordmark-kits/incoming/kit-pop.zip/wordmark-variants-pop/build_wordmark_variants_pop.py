#!/usr/bin/env python3
"""Casual-game / pop title wordmarks for Freeplug merch.

Original balloon lettering (centerline + round-pen construction), not a copy
of any existing game logo. Thick contrasting outline, glossy bevel, short
extrusion, slight bounce. Pillow/SVG + Skia only.

Light-items files (*-dark): outermost edge and extrusion in ink #171717.
Dark-items files (*-light): outermost edge and extrusion in ivory #f7f3ea.
No background plates. Does not modify the repo, Printify, or the site.
Does not touch the earlier cursive wordmark-variants set.
"""

from __future__ import annotations

import math
from pathlib import Path

import cairosvg
import numpy as np
import skia
from PIL import Image, ImageDraw, ImageFont

ROOT = Path("/workspace/logos/freeplug-merchandise/wordmark-variants-pop")
LABEL_FONT = Path("/workspace/logos/FP/fonts/ttf/FreeplugDispatch-Regular.ttf")

# Canvas
MAIN_W, MAIN_H = 4500, 1575
SQUARE_W = SQUARE_H = 4500
PORTRAIT_W, PORTRAIT_H = 4500, 6000
BAR_W, BAR_H = 4500, 692
SRC_PAD_X = 0.086266

# Palette — Freeplug Red family
RED = (139, 26, 30)          # #8B1A1E
RED_BRIGHT = (232, 62, 54)   # punchy fill highlight, still in the red family
RED_MID = (190, 36, 38)
RED_SHADE = (106, 16, 21)    # deep bevel
INK = (23, 23, 23)           # #171717
IVORY = (247, 243, 234)      # #f7f3ea
WHITE = (255, 255, 255)
NATURAL = (232, 222, 200)
CHARCOAL = (60, 60, 62)
BLACK = (0, 0, 0)
GLOSS = (255, 251, 245)
GLOSS_SOFT = (255, 220, 214)

# Glyph metrics (y-down). Visual cap ~ 0..700 after the pen inflates.
PEN = 109.0  # 30.1% thinner than v1 (156)
CAP = 700.0
BASE = 700.0
XHEIGHT = 500.0
DESC = 200.0
# Centerline insets
R = PEN / 2.0
TOP = R                 # 78
BOT = BASE - R          # 622
XTOP = (BASE - XHEIGHT) + R  # 278
DBOT = BASE + DESC - R  # 822

VERSIONS = [
    ("freeplug-dev", "Freeplug.dev"),
    ("fplgn", "FPLGN"),
    ("freeplug-in-dev", "Freeplug-in.dev"),
    ("freeplug-in", "Freeplug.in"),
]

INK_VARIANTS = {
    "dark": INK,    # light items
    "light": IVORY, # dark items
}


def hex_of(rgb: tuple[int, int, int]) -> str:
    return "#{:02x}{:02x}{:02x}".format(*rgb)


def lin(c: float) -> float:
    c = c / 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def lum(rgb: tuple[int, int, int]) -> float:
    r, g, b = rgb
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)


def contrast(a: tuple[int, int, int], b: tuple[int, int, int]) -> float:
    l1, l2 = lum(a), lum(b)
    hi, lo = max(l1, l2), min(l1, l2)
    return (hi + 0.05) / (lo + 0.05)


# ---------- path helpers ----------

def stroke_path(src: skia.Path, width: float, res: float = 8.0) -> skia.Path:
    paint = skia.Paint()
    paint.setStyle(skia.Paint.kStroke_Style)
    paint.setStrokeWidth(width)
    paint.setStrokeJoin(skia.Paint.kRound_Join)
    paint.setStrokeCap(skia.Paint.kRound_Cap)
    paint.setAntiAlias(True)
    dst = skia.Path()
    ok = paint.getFillPath(src, dst, None, res)
    if not ok or dst.isEmpty():
        return skia.Path(src)
    return dst


def union_all(paths: list[skia.Path]) -> skia.Path:
    acc = None
    for p in paths:
        if p is None or p.isEmpty():
            continue
        acc = p if acc is None else skia.Op(acc, p, skia.kUnion_PathOp)
    return acc if acc is not None else skia.Path()


def path_op(a: skia.Path, b: skia.Path, op) -> skia.Path:
    if a is None or a.isEmpty():
        return skia.Path() if op != skia.kUnion_PathOp else (b or skia.Path())
    if b is None or b.isEmpty():
        return skia.Path(a) if op in (skia.kUnion_PathOp, skia.kDifference_PathOp) else skia.Path()
    r = skia.Op(a, b, op)
    return r if r is not None else skia.Path()


def translate(path: skia.Path, dx: float, dy: float) -> skia.Path:
    out = skia.Path(path)
    out.offset(dx, dy)
    return out


def transform_path(path: skia.Path, matrix: skia.Matrix) -> skia.Path:
    out = skia.Path(path)
    out.transform(matrix)
    return out


def line(x1, y1, x2, y2) -> skia.Path:
    p = skia.Path()
    p.moveTo(x1, y1)
    p.lineTo(x2, y2)
    return p


def polyline(*xy) -> skia.Path:
    p = skia.Path()
    p.moveTo(xy[0], xy[1])
    for i in range(2, len(xy), 2):
        p.lineTo(xy[i], xy[i + 1])
    return p


def cubic(x1, y1, c1x, c1y, c2x, c2y, x2, y2) -> skia.Path:
    p = skia.Path()
    p.moveTo(x1, y1)
    p.cubicTo(c1x, c1y, c2x, c2y, x2, y2)
    return p


def disk(cx, cy, radius) -> skia.Path:
    p = skia.Path()
    p.addCircle(cx, cy, radius)
    return p


def oval_ring(cx, cy, rx, ry) -> skia.Path:
    """Centerline oval, later stroked into a ring."""
    p = skia.Path()
    p.addOval(skia.Rect.MakeLTRB(cx - rx, cy - ry, cx + rx, cy + ry))
    return p


def arc_centerline(cx, cy, rx, ry, start_deg, sweep_deg) -> skia.Path:
    p = skia.Path()
    p.addArc(skia.Rect.MakeLTRB(cx - rx, cy - ry, cx + rx, cy + ry), start_deg, sweep_deg)
    return p


def body_from_centerlines(strokes: list[skia.Path], filled: list[skia.Path] | None = None) -> skia.Path:
    parts = [stroke_path(s, PEN) for s in strokes]
    if filled:
        parts.extend(filled)
    return union_all(parts)


# ---------- original balloon alphabet (needed glyphs only) ----------

def g_F() -> skia.Path:
    # Clear capital F: stem + top bar + mid bar
    stem = line(130, TOP, 130, BOT)
    top = line(130, TOP, 455, TOP)
    mid = line(130, 330, 360, 330)
    return body_from_centerlines([stem, top, mid])


def g_L() -> skia.Path:
    # Unmistakable capital L: tall stem + long horizontal foot (not a hook).
    stem = line(140, TOP, 140, BOT)
    foot = line(140, BOT, 470, BOT)
    return body_from_centerlines([stem, foot])


def g_P() -> skia.Path:
    stem = line(130, TOP, 130, BOT)
    # Bowl occupies the upper half, open toward the stem
    ring = oval_ring(260, 250, 175, 175)
    return body_from_centerlines([stem, ring])


def g_G() -> skia.Path:
    # Open C-shaped bowl + inward bar and a downward shelf, so it cannot read as C or O.
    bowl = arc_centerline(320, 350, 245, 280, 48, 278)
    bar = line(330, 350, 545, 350)
    shelf = line(545, 350, 545, 520)
    return body_from_centerlines([bowl, bar, shelf])


def g_N() -> skia.Path:
    # Wide so the thick diagonal leaves open counters.
    left = line(140, BOT, 140, TOP)
    right = line(680, BOT, 680, TOP)
    diag = line(140, TOP, 680, BOT)
    return body_from_centerlines([left, right, diag])


def g_e() -> skia.Path:
    # Classic e: open on the upper right, visible crossbar, open lower counter.
    cx, cy, rx, ry = 230, 450, 180, 178
    bowl = arc_centerline(cx, cy, rx, ry, 28, 268)
    bar = line(cx - rx + 16, cy, cx + rx - 8, cy)
    return body_from_centerlines([bowl, bar])


def g_r() -> skia.Path:
    stem = line(120, XTOP, 120, BOT)
    # Clear high shoulder, short arm — not a hook and not an n.
    arm = cubic(120, XTOP + 8, 230, XTOP - 70, 310, XTOP - 10, 315, XTOP + 70)
    return body_from_centerlines([stem, arm])


def g_p() -> skia.Path:
    stem = line(130, XTOP, 130, DBOT)
    ring = oval_ring(275, 450, 175, 175)
    return body_from_centerlines([stem, ring])


def g_l() -> skia.Path:
    # Tall rounded stem. In "Freeplug" context this reads as l, not L or 1.
    stem = line(120, TOP, 120, BOT)
    return body_from_centerlines([stem])


def g_u() -> skia.Path:
    left = line(130, XTOP, 130, BOT - 40)
    right = line(400, XTOP, 400, BOT - 40)
    hook = cubic(130, BOT - 40, 130, BOT + 40, 400, BOT + 40, 400, BOT - 40)
    return body_from_centerlines([left, right, hook])


def g_g() -> skia.Path:
    # Single-story g: bowl at x-height + open hook tail (not a closed 8, not a q).
    ring = oval_ring(250, 450, 175, 175)
    # Tail starts at the right of the bowl and curls left under it
    tail = cubic(390, 540, 430, 700, 300, 850, 130, 800)
    return body_from_centerlines([ring, tail])


def g_d() -> skia.Path:
    stem = line(390, TOP, 390, BOT)
    ring = oval_ring(245, 450, 175, 175)
    return body_from_centerlines([stem, ring])


def g_v() -> skia.Path:
    left = line(80, XTOP, 230, BOT)
    right = line(380, XTOP, 230, BOT)
    return body_from_centerlines([left, right])


def g_i() -> skia.Path:
    stem = line(120, XTOP, 120, BOT)
    # Separate dot, clearly an i
    dot = disk(120, 110, R * 0.92)
    return body_from_centerlines([stem], filled=[dot])


def g_n() -> skia.Path:
    left = line(130, BOT, 130, XTOP)
    right = line(400, BOT, 400, XTOP + 50)
    arch = cubic(130, XTOP + 20, 130, XTOP - 50, 400, XTOP - 50, 400, XTOP + 50)
    return body_from_centerlines([left, right, arch])


def g_period() -> skia.Path:
    return disk(120, BOT - 10, R * 1.02)


def g_hyphen() -> skia.Path:
    bar = line(60, 450, 280, 450)
    return body_from_centerlines([bar])


GLYPHS = {
    "F": g_F,
    "L": g_L,
    "P": g_P,
    "G": g_G,
    "N": g_N,
    "e": g_e,
    "r": g_r,
    "p": g_p,
    "l": g_l,
    "u": g_u,
    "g": g_g,
    "d": g_d,
    "v": g_v,
    "i": g_i,
    "n": g_n,
    ".": g_period,
    "-": g_hyphen,
}


def glyph_body(ch: str) -> skia.Path:
    if ch not in GLYPHS:
        raise ValueError(f"No balloon glyph for {ch!r}")
    return GLYPHS[ch]()


def tight_bounds(path: skia.Path) -> tuple[float, float, float, float]:
    r = path.computeTightBounds()
    return r.left(), r.top(), r.right(), r.bottom()


# ---------- effects ----------

OUTLINE_W = 54.6         # 30% thinner than v1 (78)
EXTRUDE = 33.6           # 30% thinner than v1 (48)
EXTRUDE_STEPS = 7
HAIRLINE_W = 18.0        # thin outer ivory edge for dark-item files only
BOUNCE_AMP = 70.0        # rise of mid letters
TRACKING = -24.0         # slightly looser than v1; slimmer outlines need less overlap


def expand(path: skia.Path, width: float) -> skia.Path:
    """Outward offset of a filled path by stroking and unioning with the fill."""
    if width <= 0:
        return skia.Path(path)
    rim = stroke_path(path, width * 2.0)  # stroke is centered; half goes out, half in
    return path_op(path, rim, skia.kUnion_PathOp)


def letter_with_bearing(body: skia.Path) -> tuple[skia.Path, float, float, float, float]:
    x0, y0, x1, y1 = tight_bounds(body)
    return body, x0, y0, x1, y1


def layout_word(text: str) -> list[tuple[str, skia.Path, float, float]]:
    """Return (char, body_path already placed in word space with bounce, cx, cy)."""
    letters = []
    cursor = 0.0
    raw = []
    for ch in text:
        body = glyph_body(ch)
        x0, y0, x1, y1 = tight_bounds(body)
        w = x1 - x0
        raw.append((ch, body, x0, y0, x1, y1, w))
    # placement widths include a little left bearing so outlines have room
    # Shift each glyph so its left is at 0, then pack
    total = sum(w for *_, w in raw) + TRACKING * (len(raw) - 1)
    x = 0.0
    placed = []
    centers = []
    for ch, body, x0, y0, x1, y1, w in raw:
        cx = x + w / 2.0
        cy = (y0 + y1) / 2.0  # will be rewritten after move
        centers.append((cx, (y0 + y1) / 2.0, w, y0, y1))
        # move body so left edge is at x
        moved = translate(body, -x0 + x, 0)
        placed.append((ch, moved, x, w, y0, y1))
        x += w + TRACKING
    total_w = x - TRACKING
    # Bounce along a gentle arch + follow-the-arc rotation
    out = []
    for ch, moved, xleft, w, y0, y1, in placed:
        cx = xleft + w / 2.0
        t = 0.0 if total_w <= 0 else cx / total_w
        y_off = -BOUNCE_AMP * math.sin(math.pi * t)
        # dy/dx of -amp*sin(pi x / W) = -amp * pi/W * cos(pi t)
        slope = -BOUNCE_AMP * math.pi / max(total_w, 1.0) * math.cos(math.pi * t)
        angle = math.degrees(math.atan(slope))
        cy = (y0 + y1) / 2.0 + y_off
        m = skia.Matrix()
        m.setRotate(angle, cx, (y0 + y1) / 2.0)
        m.postTranslate(0, y_off)
        bounced = transform_path(moved, m)
        out.append((ch, bounced, cx, cy))
    return out


def word_effects(text: str):
    """Build per-letter body, outline, extrusion, bevel, gloss in word space."""
    laid = layout_word(text)
    items = []
    for ch, body, cx, cy in laid:
        outline = expand(body, OUTLINE_W)
        # extrusion as stacked outline copies (solid block, no blur)
        dx = EXTRUDE * 0.75
        dy = EXTRUDE
        extrusion = skia.Path()
        for i in range(1, EXTRUDE_STEPS + 1):
            t = i / EXTRUDE_STEPS
            extrusion = path_op(extrusion, translate(outline, dx * t, dy * t), skia.kUnion_PathOp)
        # keep extrusion only where it sticks out from the face outline
        extrusion = path_op(extrusion, outline, skia.kDifference_PathOp)
        # bevel crescent: body minus a copy shifted up-left
        shift = 28.0
        bevel = path_op(body, translate(body, -shift, -shift), skia.kDifference_PathOp)
        # gloss highlight: ellipse in the upper-left, intersected with a slightly inset body
        x0, y0, x1, y1 = tight_bounds(body)
        bw, bh = x1 - x0, y1 - y0
        ell = skia.Path()
        ell.addOval(skia.Rect.MakeLTRB(
            x0 + bw * 0.10,
            y0 + bh * 0.07,
            x0 + bw * 0.72,
            y0 + bh * 0.42,
        ))
        inset = expand(body, -8) if False else body  # use body; clip by intersection
        # shrink body slightly so gloss stays inside the fill, not the outline
        # Approximate inset: difference of body with a small inner isn't easy;
        # intersect with body is enough because gloss sits under the outline layer.
        gloss = path_op(ell, body, skia.kIntersect_PathOp)
        # smaller hot specular
        ell2 = skia.Path()
        ell2.addOval(skia.Rect.MakeLTRB(
            x0 + bw * 0.16,
            y0 + bh * 0.10,
            x0 + bw * 0.42,
            y0 + bh * 0.26,
        ))
        gloss2 = path_op(ell2, body, skia.kIntersect_PathOp)
        items.append({
            "ch": ch,
            "body": body,
            "outline": outline,
            "extrusion": extrusion,
            "bevel": bevel,
            "gloss": gloss,
            "gloss2": gloss2,
        })
    return items


def group_bounds(items, include_extrusion=True):
    minx = miny = 1e18
    maxx = maxy = -1e18
    for it in items:
        paths = [it["outline"]]
        if include_extrusion:
            paths.append(it["extrusion"])
        for p in paths:
            if p.isEmpty():
                continue
            x0, y0, x1, y1 = tight_bounds(p)
            minx, miny = min(minx, x0), min(miny, y0)
            maxx, maxy = max(maxx, x1), max(maxy, y1)
    return minx, miny, maxx, maxy


# ---------- SVG ----------

def _fmt(n: float) -> str:
    s = f"{n:.3f}"
    if s.endswith(".000"):
        return s[:-4]
    return s


def path_to_d(path: skia.Path) -> str:
    if path is None or path.isEmpty():
        return ""
    parts: list[str] = []
    it = skia.Path.Iter(path, False)
    for verb, pts in it:
        if verb == skia.Path.kMove_Verb:
            parts.append(f"M{_fmt(pts[0].fX)} {_fmt(pts[0].fY)}")
        elif verb == skia.Path.kLine_Verb:
            parts.append(f"L{_fmt(pts[-1].fX)} {_fmt(pts[-1].fY)}")
        elif verb == skia.Path.kQuad_Verb:
            parts.append(f"Q{_fmt(pts[1].fX)} {_fmt(pts[1].fY)} {_fmt(pts[2].fX)} {_fmt(pts[2].fY)}")
        elif verb == skia.Path.kCubic_Verb:
            parts.append(
                f"C{_fmt(pts[1].fX)} {_fmt(pts[1].fY)} {_fmt(pts[2].fX)} {_fmt(pts[2].fY)} "
                f"{_fmt(pts[3].fX)} {_fmt(pts[3].fY)}"
            )
        elif verb == skia.Path.kConic_Verb:
            w = it.conicWeight()
            # ConvertConicToQuads(p0, p1, p2, w, pts_out, pow2) — try common signatures
            quads = _conic_to_quads(pts[0], pts[1], pts[2], w)
            for q in quads:
                parts.append(f"Q{_fmt(q[1].fX)} {_fmt(q[1].fY)} {_fmt(q[2].fX)} {_fmt(q[2].fY)}")
        elif verb == skia.Path.kClose_Verb:
            parts.append("Z")
        elif verb == skia.Path.kDone_Verb:
            break
    return " ".join(parts)


def _conic_to_quads(p0, p1, p2, w, pow2: int = 3):
    try:
        pts = skia.Path.ConvertConicToQuads(p0, p1, p2, w, pow2)
        # expected: list of points, 2*quads+1 or groups of 3
        if pts is None:
            return [(p0, p1, p2)]
        # flatten into quads
        if isinstance(pts, (list, tuple)) and len(pts) >= 3:
            # sometimes returns a point array of length 1+2*(2**pow2)
            quads = []
            # if first is start
            arr = list(pts)
            if len(arr) % 2 == 1:
                i = 0
                while i + 2 < len(arr):
                    quads.append((arr[i], arr[i + 1], arr[i + 2]))
                    i += 2
                return quads or [(p0, p1, p2)]
        return [(p0, p1, p2)]
    except TypeError:
        # alternate signature
        try:
            out = []
            n = skia.Path.ConvertConicToQuads(p0, p1, p2, w, out, pow2)
            quads = []
            if out:
                arr = list(out)
                i = 0
                while i + 2 < len(arr):
                    quads.append((arr[i], arr[i + 1], arr[i + 2]))
                    i += 2
                return quads or [(p0, p1, p2)]
        except Exception:
            pass
        return [(p0, p1, p2)]


def apply_canvas_transform(path: skia.Path, tx: float, ty: float, scale: float) -> skia.Path:
    m = skia.Matrix()
    m.setScale(scale, scale)
    m.postTranslate(tx, ty)
    return transform_path(path, m)


def word_space_bounds(items, hairline: bool = False):
    minx, miny, maxx, maxy = group_bounds(items, include_extrusion=True)
    if hairline:
        minx -= HAIRLINE_W
        miny -= HAIRLINE_W
        maxx += HAIRLINE_W
        maxy += HAIRLINE_W
    return minx, miny, maxx, maxy


def hairline_path(items):
    combined = union_all([it["outline"] for it in items] + [it["extrusion"] for it in items])
    return expand(combined, HAIRLINE_W)


def word_to_svg(text: str, canvas_w: int, canvas_h: int, scale: float, *, hairline: bool = False) -> str:
    """Red fill, black (#171717) outline and extrusion. Optional thin ivory hairline around the whole mark."""
    items = word_effects(text)
    minx, miny, maxx, maxy = word_space_bounds(items, hairline=hairline)
    content_w = (maxx - minx) * scale
    content_h = (maxy - miny) * scale
    tx = (canvas_w - content_w) / 2.0 - minx * scale
    ty = (canvas_h - content_h) / 2.0 - miny * scale

    def xf(p):
        return apply_canvas_transform(p, tx, ty, scale)

    ol = hex_of(INK)
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{canvas_w}" height="{canvas_h}" '
        f'viewBox="0 0 {canvas_w} {canvas_h}">',
        "<defs>",
        '<linearGradient id="fillGrad" x1="0" y1="0" x2="0.35" y2="1">',
        f'<stop offset="0%" stop-color="{hex_of(RED_BRIGHT)}"/>',
        f'<stop offset="55%" stop-color="{hex_of(RED_MID)}"/>',
        f'<stop offset="100%" stop-color="{hex_of(RED)}"/>',
        "</linearGradient>",
        "</defs>",
    ]
    # optional ivory hairline first, so it is the outermost edge on dark garments
    if hairline:
        d_hair = path_to_d(xf(hairline_path(items)))
        if d_hair.strip():
            parts.append(f'<path fill="{hex_of(IVORY)}" d="{d_hair}"/>')
    # black extrusion (backlay) and black outlines
    ext_u = union_all([xf(it["extrusion"]) for it in items])
    ol_u = union_all([xf(it["outline"]) for it in items])
    d_ext = path_to_d(ext_u)
    if d_ext.strip():
        parts.append(f'<path fill="{ol}" d="{d_ext}"/>')
    d_ol = path_to_d(ol_u)
    parts.append(f'<path fill="{ol}" d="{d_ol}"/>')
    # fill
    d_body = " ".join(path_to_d(xf(it["body"])) for it in items)
    parts.append(f'<path fill="url(#fillGrad)" d="{d_body}"/>')
    # bevel
    d_bev = " ".join(path_to_d(xf(it["bevel"])) for it in items if not it["bevel"].isEmpty())
    if d_bev.strip():
        parts.append(f'<path fill="{hex_of(RED_SHADE)}" fill-opacity="0.55" d="{d_bev}"/>')
    # gloss
    d_g = " ".join(path_to_d(xf(it["gloss"])) for it in items if not it["gloss"].isEmpty())
    if d_g.strip():
        parts.append(f'<path fill="{hex_of(GLOSS_SOFT)}" fill-opacity="0.72" d="{d_g}"/>')
    d_g2 = " ".join(path_to_d(xf(it["gloss2"])) for it in items if not it["gloss2"].isEmpty())
    if d_g2.strip():
        parts.append(f'<path fill="{hex_of(GLOSS)}" fill-opacity="0.92" d="{d_g2}"/>')
    parts.append("</svg>")
    return "\n".join(parts)


def main_scale(include_hairline: bool = False) -> float:
    items = word_effects("Freeplug-in.dev")
    minx, miny, maxx, maxy = word_space_bounds(items, hairline=include_hairline)
    fu_w = maxx - minx
    target_w = MAIN_W * (1.0 - 2.0 * SRC_PAD_X)
    return target_w / fu_w


def bar_scale(main_s: float, include_hairline: bool = False) -> float:
    pad_x, pad_y = SRC_PAD_X, 0.18
    s = main_s
    for _, text in VERSIONS:
        items = word_effects(text)
        minx, miny, maxx, maxy = word_space_bounds(items, hairline=include_hairline)
        max_s_w = (BAR_W * (1.0 - 2.0 * pad_x)) / (maxx - minx)
        max_s_h = (BAR_H * (1.0 - 2.0 * pad_y)) / (maxy - miny)
        s = min(s, max_s_w, max_s_h)
    return s


def write_svg_png(svg: str, svg_path: Path, png_path: Path, canvas_w: int, canvas_h: int) -> Image.Image:
    svg_path.write_text(svg, encoding="utf-8")
    cairosvg.svg2png(
        bytestring=svg.encode("utf-8"),
        write_to=str(png_path),
        output_width=canvas_w,
        output_height=canvas_h,
        background_color="rgba(0,0,0,0)",
    )
    im = Image.open(png_path).convert("RGBA")
    if im.size != (canvas_w, canvas_h):
        raise RuntimeError(f"{png_path} is {im.size}, expected {(canvas_w, canvas_h)}")
    return im


def panel_pixel_count(im: Image.Image, outline: tuple[int, int, int], tol: int = 40) -> dict:
    arr = np.array(im)
    a = arr[:, :, 3]
    rgb = arr[:, :, :3].astype(int)
    opa = a > 20
    # "other" = opaque pixels that are not near outline, red family, ivory/gloss, or ink
    palette = [
        outline, INK, IVORY, RED, RED_BRIGHT, RED_MID, RED_SHADE, GLOSS, GLOSS_SOFT, WHITE,
    ]
    near = np.zeros(opa.shape, dtype=bool)
    for col in palette:
        dist = np.max(np.abs(rgb - np.array(col)[None, None, :]), axis=2)
        near |= dist <= tol
    # also treat any reasonably red pixel as in-family (gradient / AA)
    redish = (rgb[:, :, 0] >= rgb[:, :, 1] + 20) & (rgb[:, :, 0] >= rgb[:, :, 2] + 20) & (rgb[:, :, 0] > 60)
    inkish = (np.max(np.abs(rgb - np.array(INK)[None, None, :]), axis=2) <= 50)
    ivoryish = (rgb[:, :, 0] >= 220) & (rgb[:, :, 1] >= 200) & (rgb[:, :, 2] >= 190)
    family = opa & (near | redish | inkish | ivoryish)
    other = opa & ~family
    whiteish = other & (rgb[:, :, 0] >= 240) & (rgb[:, :, 1] >= 240) & (rgb[:, :, 2] >= 240)
    blackish = other & (rgb[:, :, 0] <= 30) & (rgb[:, :, 1] <= 30) & (rgb[:, :, 2] <= 30)
    plate = other  # any leftover mass would be a plate
    return {
        "opaque": int(opa.sum()),
        "other": int(other.sum()),
        "whiteish": int(whiteish.sum()),
        "blackish": int(blackish.sum()),
        "bbox": Image.fromarray((opa * 255).astype("uint8")).getbbox(),
    }


def composite_on(im: Image.Image, bg: tuple[int, int, int]) -> Image.Image:
    out = Image.new("RGB", im.size, bg)
    out.paste(im, mask=im.split()[-1])
    return out


def load_label_font(size: int):
    if LABEL_FONT.exists():
        return ImageFont.truetype(str(LABEL_FONT), size=size)
    return ImageFont.load_default()


def build_overview(previews: dict, out_path: Path):
    cell_w, cell_h = 1200, 420
    row_label_w = 360
    header_h = 80
    footer_h = 90
    pad = 28
    gap_y = 28
    cols = [
        ("ink outline on white", "dark", WHITE),
        ("ink outline on natural", "dark", NATURAL),
        ("ink + ivory hairline on charcoal", "light", CHARCOAL),
        ("ink + ivory hairline on black", "light", BLACK),
    ]
    width = row_label_w + len(cols) * (cell_w + pad) + pad
    height = header_h + len(VERSIONS) * (cell_h + gap_y) + footer_h
    canvas = Image.new("RGB", (width, height), (248, 246, 240))
    draw = ImageDraw.Draw(canvas)
    title_font = load_label_font(42)
    small = load_label_font(28)
    tiny = load_label_font(26)
    x0 = row_label_w
    for i, (label, _, _) in enumerate(cols):
        cx = x0 + i * (cell_w + pad) + cell_w // 2
        bbox = draw.textbbox((0, 0), label, font=small)
        tw = bbox[2] - bbox[0]
        draw.text((cx - tw // 2, 24), label, fill=(30, 30, 32), font=small)
    y = header_h
    for slug, text in VERSIONS:
        tb = draw.textbbox((0, 0), text, font=title_font)
        tw, th = tb[2] - tb[0], tb[3] - tb[1]
        draw.text((24, y + (cell_h - th) // 2 - tb[1]), text, fill=(30, 30, 32), font=title_font)
        for i, (label, ink_key, bg) in enumerate(cols):
            im = previews[(slug, ink_key)]
            iw, ih = im.size
            scale = min((cell_w - 40) / iw, (cell_h - 20) / ih)
            nw, nh = max(1, int(iw * scale)), max(1, int(ih * scale))
            resized = im.resize((nw, nh), Image.Resampling.LANCZOS)
            cell = Image.new("RGB", (cell_w, cell_h), bg)
            cell.paste(resized, ((cell_w - nw) // 2, (cell_h - nh) // 2), resized)
            cx = x0 + i * (cell_w + pad)
            canvas.paste(cell, (cx, y))
            draw.rectangle([cx, y, cx + cell_w - 1, y + cell_h - 1], outline=(200, 196, 188))
        y += cell_h + gap_y
    foot = (
        "Casual-game pop title  ·  30% thinner lettering  ·  "
        "ink #171717 outline/extrusion  ·  ivory hairline on dark items  ·  4500×1575 (20:7)"
    )
    fb = draw.textbbox((0, 0), foot, font=tiny)
    draw.text(((width - (fb[2] - fb[0])) // 2, height - 58), foot, fill=(90, 88, 84), font=tiny)
    canvas.save(out_path, "PNG")


def contrast_rows() -> list[str]:
    def row(a, b, label):
        c = contrast(a, b)
        return f"| {label} | {c:.2f}:1 | {'PASS' if c >= 4.5 else 'FAIL'} |"

    rows = [
        row(INK, WHITE, "outer edge ink #171717 vs white (light-items / *-dark)"),
        row(INK, NATURAL, "outer edge ink #171717 vs natural (232,222,200)"),
        row(IVORY, BLACK, "outer edge ivory #f7f3ea vs black (dark-items / *-light)"),
        row(IVORY, CHARCOAL, "outer edge ivory #f7f3ea vs charcoal (60,60,62)"),
        row(RED_BRIGHT, WHITE, "fill highlight #e83e36 vs white"),
        row(RED_BRIGHT, NATURAL, "fill highlight #e83e36 vs natural"),
        row(RED_BRIGHT, BLACK, "fill highlight #e83e36 vs black"),
        row(RED_BRIGHT, CHARCOAL, "fill highlight #e83e36 vs charcoal"),
        row(RED_MID, WHITE, "fill mid #be2426 vs white"),
        row(RED_MID, NATURAL, "fill mid #be2426 vs natural"),
        row(RED_MID, BLACK, "fill mid #be2426 vs black"),
        row(RED_MID, CHARCOAL, "fill mid #be2426 vs charcoal"),
        row(RED, WHITE, "fill base Freeplug Red #8B1A1E vs white"),
        row(RED, NATURAL, "fill base Freeplug Red #8B1A1E vs natural"),
        row(RED, BLACK, "fill base Freeplug Red #8B1A1E vs black"),
        row(RED, CHARCOAL, "fill base Freeplug Red #8B1A1E vs charcoal"),
    ]
    return rows


def write_manifest(main_s: float, bar_s: float, written: list[str]):
    lines = []
    lines.append("# Freeplug merch wordmark variants — casual-game pop title")
    lines.append("")
    lines.append("Updated 11 November 2026, America/Chicago (8:16 AM CT). Cheke asked to thin the uncurly lettering and change the pale letter backlay to black. v1 files are in `before/pop-v1/`. Cursive sets are untouched.")
    lines.append("Print files only. Repo, Printify, and the site were not modified.")
    lines.append("")
    lines.append("## Style")
    lines.append("")
    lines.append("Original balloon lettering drawn as centerlines and inflated with a round pen. v2 is **30% thinner** than v1: pen 156→109, outline 78→54.6, extrusion 48→33.6. The playful casual-game feel, bounce, gloss, and the geometric FPLGN L are unchanged. It is inspired by casual-puzzle-game title art as a genre and is not a copy of any existing game logo.")
    lines.append("")
    lines.append("- Palette is anchored on Freeplug Red `#8B1A1E`, with a punchy lighter red at the top of the fill, ivory `#f7f3ea` highlights, and ink `#171717`.")
    lines.append("- Light-items files (`*-dark`): outermost outline and extrusion in ink `#171717`.")
    lines.append("- Dark-items files (`*-light`): outermost outline and extrusion in ivory `#f7f3ea`.")
    lines.append("- No background plate; canvas is transparent outside the letters.")
    lines.append("- FPLGN uses a geometric capital L (vertical stem + long horizontal foot) so it cannot be read as a 2. Ligatures are not used; each letter is its own path.")
    lines.append("- One typographic size is shared across the four versions, fitted so `Freeplug-in.dev` (with outline and extrusion) has 8.63% side padding on the main 20:7 canvas. Shorter marks are centered at that size, with a gentle arch and follow-the-arc rotation.")
    lines.append("")
    lines.append("Lettering is original to this job (not FP Cursive, not FP Extended, not a third-party display face).")
    lines.append("")
    lines.append("## Canvas ratios")
    lines.append("")
    lines.append(f"- **Main (20:7)** — `{MAIN_W} × {MAIN_H}` px. Scale {main_s:.8f}. Files at the folder root.")
    lines.append(f"- **Square (1:1)** — `{SQUARE_W} × {SQUARE_H}` px, same letter size as main, centered. Subfolder `square/`.")
    lines.append(f"- **Portrait (3:4)** — `{PORTRAIT_W} × {PORTRAIT_H}` px, same letter size as main, centered. Subfolder `portrait/`.")
    lines.append(f"- **Bar (6.5:1)** — `{BAR_W} × {BAR_H}` px, scale {bar_s:.8f}. Subfolder `bar/`.")
    lines.append("")
    lines.append("Mapping is the same as the cursive set: main files for the 267 baked plain SKUs; `square/` for fanny-pack-468, glass-cutting-board-938, garden-house-banner-976; `portrait/` for the two matte canvases and metal-art-sign-1206; `bar/` for the bracelet engraving aspect (the live engraving remains a different, Extended Black style). The PR #59 CSV has no print-area columns; this mapping is inferred from the 1500×525 shop asset and coming-soon-7 print specs.")
    lines.append("")
    lines.append("## Contrast (WCAG relative luminance)")
    lines.append("")
    lines.append("Required: the outermost edge hits at least 4.5:1 against white and natural for the ink-outline (light-items) files, and against black and charcoal for the ivory-hairline (dark-items) files. Fill-to-garment ratios are reported as well; the red fill fails on dark garments, which is why the ivory hairline is the contrast edge there.")
    lines.append("")
    lines.append("| Pair | Ratio | Result |")
    lines.append("|---|---|---|")
    lines.extend(contrast_rows())
    lines.append("")
    lines.append("## Files")
    lines.append("")
    lines.append("Naming: `<slug>-<light|dark>.png` / `.svg`. `light` = dark items (black outline + ivory hairline). `dark` = light items (black outline). SVGs are paths only (no live text).")
    lines.append("")
    for p in written:
        lines.append(f"- `{p}`")
    lines.append("")
    lines.append("Overview: `overview.png` — all 4 versions × ink outline on white and natural, ink + ivory hairline on charcoal and black.")
    lines.append("")
    lines.append("## Rebuild")
    lines.append("")
    lines.append("```sh")
    lines.append("python3 /workspace/logos/freeplug-merchandise/wordmark-variants-pop/build_wordmark_variants_pop.py")
    lines.append("```")
    lines.append("")
    (ROOT / "MANIFEST.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def render_preview(out: Path):
    """Mid-res specimen for visual QA of glyphs and the four titles."""
    # alphabet strip + four titles on white / charcoal
    main_s = main_scale(include_hairline=True) * (1800 / MAIN_W)
    tiles = []
    # alphabet
    alphabet = "FPLGNe rplug.dvin-"
    # unique needed
    needed = "FPLGNervplug.din-"
    # render each glyph isolated
    gw, gh = 280, 360
    chars = ["F", "P", "L", "G", "N", "e", "r", "p", "l", "u", "g", "d", "v", "i", "n", ".", "-"]
    strip = Image.new("RGB", (gw * len(chars), gh + 40), (255, 255, 255))
    d = ImageDraw.Draw(strip)
    lab = load_label_font(22)
    for i, ch in enumerate(chars):
        svg = word_to_svg(ch, gw, gh, main_s * 1.6 if ch in ".-" else main_s * 1.15, hairline=False)
        tmp = Path("/tmp") / f"glyph-{i}.png"
        cairosvg.svg2png(bytestring=svg.encode(), write_to=str(tmp), output_width=gw, output_height=gh, background_color="rgba(0,0,0,0)")
        g = Image.open(tmp).convert("RGBA")
        cell = Image.new("RGB", (gw, gh), (255, 255, 255))
        cell.paste(g, mask=g.split()[-1])
        strip.paste(cell, (i * gw, 0))
        label = ch if ch != " " else "sp"
        d.text((i * gw + 10, gh + 8), repr(ch), fill=(30, 30, 32), font=lab)
    strip.save(out.parent / "preview-glyphs.png")

    # four titles, dark and light, two backgrounds
    W, H = 1800, 630
    cols = 2
    rows = 4
    board = Image.new("RGB", (W * 2 + 40, H * 4 + 80), (240, 238, 232))
    for r, (slug, text) in enumerate(VERSIONS):
        for c, (ink_key, bg) in enumerate((("dark", WHITE), ("light", CHARCOAL))):
            svg = word_to_svg(text, W, H, main_s, hairline=(ink_key == "light"))
            tmp = Path("/tmp") / f"prev-{slug}-{ink_key}.png"
            cairosvg.svg2png(bytestring=svg.encode(), write_to=str(tmp), output_width=W, output_height=H, background_color="rgba(0,0,0,0)")
            im = Image.open(tmp).convert("RGBA")
            cell = Image.new("RGB", (W, H), bg)
            cell.paste(im, mask=im.split()[-1])
            board.paste(cell, (c * (W + 40), r * H))
    board.save(out)
    print("preview written", out, board.size)


def produce_all():
    ROOT.mkdir(parents=True, exist_ok=True)
    for sub in ("square", "portrait", "bar", "_proof"):
        (ROOT / sub).mkdir(exist_ok=True)

    main_s = main_scale(include_hairline=True)
    bar_s = bar_scale(main_s, include_hairline=True)
    print(f"main scale {main_s:.8f}")
    print(f"bar scale  {bar_s:.8f}")
    for slug, text in VERSIONS:
        items = word_effects(text)
        minx, miny, maxx, maxy = group_bounds(items, True)
        w = (maxx - minx) * main_s
        h = (maxy - miny) * main_s
        print(f"  {text!r:22} main content {w:.1f}x{h:.1f}  "
              f"pad x {(MAIN_W-w)/2/MAIN_W*100:.2f}%  y {(MAIN_H-h)/2/MAIN_H*100:.2f}%")

    groups = [
        (ROOT, MAIN_W, MAIN_H, main_s, "main"),
        (ROOT / "square", SQUARE_W, SQUARE_H, main_s, "square"),
        (ROOT / "portrait", PORTRAIT_W, PORTRAIT_H, main_s, "portrait"),
        (ROOT / "bar", BAR_W, BAR_H, bar_s, "bar"),
    ]
    written = []
    previews = {}
    for dest, cw, ch, scale, group_name in groups:
        for slug, text in VERSIONS:
            for ink_key, color in INK_VARIANTS.items():
                svg = word_to_svg(text, cw, ch, scale, hairline=(ink_key == "light"))
                svg_path = dest / f"{slug}-{ink_key}.svg"
                png_path = dest / f"{slug}-{ink_key}.png"
                im = write_svg_png(svg, svg_path, png_path, cw, ch)
                stats = panel_pixel_count(im, INK)
                if group_name == "main" and ink_key == "dark":
                    for bgname, bg in (("natural", NATURAL), ("charcoal", CHARCOAL), ("white", WHITE)):
                        composite_on(im, bg).save(ROOT / "_proof" / f"{slug}-{ink_key}-on-{bgname}.png")
                if group_name == "main" and ink_key == "light":
                    for bgname, bg in (("charcoal", CHARCOAL), ("black", BLACK), ("natural", NATURAL)):
                        composite_on(im, bg).save(ROOT / "_proof" / f"{slug}-{ink_key}-on-{bgname}.png")
                if group_name == "main":
                    previews[(slug, ink_key)] = im
                written.append(str(png_path.relative_to(ROOT)))
                written.append(str(svg_path.relative_to(ROOT)))
                print(f"wrote {png_path.relative_to(ROOT)}  opaque={stats['opaque']} other={stats['other']} "
                      f"white={stats['whiteish']} black={stats['blackish']} bbox={stats['bbox']}")
                if stats["other"] > 8000 or stats["whiteish"] > 2000:
                    print(f"  WARNING leftover pixels: {stats}")

    overview_path = ROOT / "overview.png"
    build_overview(previews, overview_path)
    written.insert(0, "overview.png")
    print(f"wrote overview {overview_path.stat().st_size} {overview_path}")
    write_manifest(main_s, bar_s, written)
    print("done")


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--preview":
        ROOT.mkdir(parents=True, exist_ok=True)
        render_preview(ROOT / "preview-titles.png")
    else:
        produce_all()
