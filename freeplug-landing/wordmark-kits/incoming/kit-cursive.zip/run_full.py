#!/usr/bin/env python3
"""Approved operational Printify draft assembly; never updates existing products."""
import os,json,csv,re,time,base64,hashlib,unicodedata,fcntl,traceback
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from collections import defaultdict
import requests
from PIL import Image,ImageDraw,ImageFont,ImageOps
W=Path('/workspace/printify-work/full-run'); ART=Path('/workspace/logos/freeplug-merchandise'); SHOP=29664778
CSV='/cursor/stores/user/grok-bot/agents/28e038c9-e255-4f56-bb7e-be27717569bf/assets/01M74X4F5R13V48R0RC58F1S72.csv'
STYLES=[('Cursive','wordmark-variants'),('Cursive Plate','wordmark-variants-plate'),('Pop','wordmark-variants-pop'),('Pop Plate','wordmark-variants-pop-plate')]
MARKS=[('Freeplug.dev','freeplug-dev'),('FPLGN','fplgn'),('Freeplug-in.dev','freeplug-in-dev'),('Freeplug.in','freeplug-in')]
TEST={583,145,553};TOKEN=os.environ['PRINTIFY_API_TOKEN'];S=requests.Session();S.headers.update({'Authorization':'Bearer '+TOKEN,'User-Agent':'Freeplug-approved-drafts-only','Content-Type':'application/json'})
LAST=0; PRODUCTS=[]
def now():return datetime.now(ZoneInfo('America/Chicago')).isoformat()
def log(s):print(now(),str(s).replace(TOKEN,'[REDACTED]'),flush=True)
def save(name,obj):
 t=W/(name+'.tmp');t.write_text(json.dumps(obj,indent=2));t.replace(W/name)
def norm(s):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',s).lower())
class HardStop(Exception):pass
class ItemSkip(Exception):pass

def req(method,path,body=None):
 global LAST
 assert method in ('GET','POST') and 'publish' not in path and 'orders' not in path
 if method=='POST':assert path in (f'/shops/{SHOP}/products.json','/uploads/images.json')
 for attempt in range(7):
  time.sleep(max(0,1.05-(time.monotonic()-LAST)));LAST=time.monotonic()
  try:r=S.request(method,'https://api.printify.com/v1'+path,json=body,timeout=(20,150))
  except requests.RequestException as e:
   # POST may have succeeded. Never blindly repeat a product creation.
   if method=='POST' and '/products' in path:raise HardStop('Uncertain product creation outcome; resume to reconcile titles: '+str(e))
   if attempt==6:raise HardStop('Network unavailable: '+str(e))
   time.sleep(min(180,3*2**attempt));continue
  if r.status_code in (401,403):raise HardStop(f'Authorization error HTTP {r.status_code}')
  if r.status_code==429 or r.status_code>=500:
   if method=='POST' and '/products' in path and r.status_code>=500:raise HardStop(f'Uncertain creation HTTP {r.status_code}; resume reconciles titles')
   if attempt==6:raise HardStop(f'HTTP {r.status_code} retry budget exhausted: '+r.text[:500])
   delay=max(float(r.headers.get('Retry-After','0') or 0),min(180,4*2**attempt));log(f'Backoff HTTP {r.status_code}: {delay}s');time.sleep(delay);continue
  if not r.ok:raise ItemSkip(f'HTTP {r.status_code}: '+r.text[:900])
  return r.json()

def all_products():
 a=[]
 for page in range(1,200):
  j=req('GET',f'/shops/{SHOP}/products.json?limit=50&page={page}');a.extend(j['data'])
  if page>=j['last_page']:return a
 raise HardStop('Product pagination overflow')

def artid(path):
 key=str(path);sha=hashlib.sha256(path.read_bytes()).hexdigest()
 if key in STATE['uploads'] and STATE['uploads'][key]['sha256']==sha:return STATE['uploads'][key]['id']
 j=req('POST','/uploads/images.json',{'file_name':'fp-'+path.parent.name+'-'+path.name,'contents':base64.b64encode(path.read_bytes()).decode()})
 STATE['uploads'][key]={'id':j['id'],'sha256':sha};checkpoint();return j['id']

def checkpoint():
 STATE['updated_at_ct']=now();STATE['counts']={'created_new':len(STATE['created']),'existing_titles_reused':len(STATE['existing']),'skipped_items':len(STATE['skipped']),'failed_products':len(STATE['failures']),'complete_items':len(STATE['complete_items'])}
 save('progress.json',STATE)
 out=defaultdict(list)
 for d in STATE['existing']+STATE['created']:
  if d['product_id'] not in out[d['slug']]:out[d['slug']].append(d['product_id'])
 save('created.json',dict(out))

def source_for(row):
 bp=int(row['slug'].rsplit('-',1)[1]);want=norm('Freeplug '+row['product_name'])
 c=[p for p in PRODUCTS if p['blueprint_id']==bp and (norm(p['title'])==want or norm(re.sub(r' \(\d+ of \d+\)$','',p['title']))==want)]
 if not c:
  # The six coming-soon source setups use descriptive rather than plain names.
  ids={468:'6af1fa9d8f2824f6ff06c9a8',976:'6af1fab72cc8ec45d00d9de5',938:'6af1faabdbbd8cf3320775ea',937:'6af1fce241cb545504055367',1159:'6af1fbdafa2e2c9c62013b1c',1206:'6af1fae9aa2444f8860b39e2'}
  c=[p for p in PRODUCTS if p['id']==ids.get(bp)]
 if not c:raise ItemSkip('No unambiguous source setup')
 if len({p['print_provider_id'] for p in c})!=1:raise ItemSkip('Split sources use different providers')
 c=sorted(c,key=lambda p:p['created_at'],reverse=True)
 # Union enabled variants across split source products; latest duplicate takes precedence.
 variants={};config={};catalogopts={}
 for p in c:
  for opt in p.get('options',[]):
   if opt.get('type')=='color':
    for v in opt['values']:catalogopts[v['id']]=v
  for v in p['variants']:
   if v['is_enabled'] and v['id'] not in variants:
    variants[v['id']]={k:v[k] for k in ['id','price']};variants[v['id']]['is_enabled']=True
    choices=[]
    for a in p['print_areas']:
     if v['id'] not in a['variant_ids']:continue
     for ph in a['placeholders']:
      if ph.get('images') and ph['position'] not in ('neck','back','inside','outside'):
       choices.append(ph)
    if not choices:raise ItemSkip(f'No existing supported logo surface for enabled variant {v["id"]}')
    # Prefer a front/chest logo over incidental text labels or other surfaces.
    choices.sort(key=lambda ph:(not('front' in ph['position'] or 'chest' in ph['position']),ph['position']))
    ph=choices[0];ims=[i for i in ph['images'] if i.get('scale') is not None and i.get('type')!='text']
    if not ims:raise ItemSkip('Source has no measurable image scale')
    im=ims[0];color=next((catalogopts[o] for o in v.get('options',[]) if o in catalogopts),None)
    ink='light' if 'light-ink' in im.get('name','') else 'dark'
    # Mug color options refer to handles/interiors; their white print body stays dark ink.
    if color and not re.search('mug',row['product_name'],re.I):
     hs=color.get('colors',[])
     if hs and re.fullmatch('#[0-9a-fA-F]{6}',hs[0]):
      rgb=[int(hs[0][i:i+2],16)/255 for i in (1,3,5)];lin=[t/12.92 if t<=.04045 else ((t+.055)/1.055)**2.4 for t in rgb];lum=sum(a*b for a,b in zip(lin,[.2126,.7152,.0722]));ink='light' if lum<.30 else 'dark'
     if re.search(r'\b(coal|black|charcoal|navy)\b',color['title'],re.I):ink='light'
    if 'black mug' in row['product_name'].lower():ink='light'
    config[v['id']]={'position':ph['position'],'decoration_method':ph.get('decoration_method'),'scale':im['scale'],'ink':ink,'source_image':im.get('name'),'color':color}
 if not variants:raise ItemSkip('No enabled variants')
 desc=c[0].get('description','')
 if re.search(r'supreme|popcap',desc,re.I):raise ItemSkip('Source description contains forbidden brand text; not copied')
 return c,variants,config,desc

def aspect(bp):
 if bp in [468,938,976]:return 'square'
 if bp in [937,1159,1206]:return 'portrait'
 if bp==2651:return 'bar'
 return ''
def upper(row):
 return bool(re.search(r'tee|t-shirt|hoodie|sweatshirt|tank|crew|bodysuit|onesie|henley|jacket|long sleeve|v-neck|apron',row['product_name'],re.I))

def plan(row):
 c,variants,config,desc=source_for(row);bp=c[0]['blueprint_id'];pp=c[0]['print_provider_id']
 catpath=W/f'catalog-{bp}-{pp}.json'
 if catpath.exists():cat=json.loads(catpath.read_text())
 else:cat=req('GET',f'/catalog/blueprints/{bp}/print_providers/{pp}/variants.json?show-out-of-stock=1');save(catpath.name,cat)
 cats={v['id']:v for v in cat['variants']}
 for vid,cf in config.items():
  if vid not in cats:raise ItemSkip(f'Enabled variant {vid} not in current provider catalog')
  ph=next((p for p in cats[vid]['placeholders'] if p['position']==cf['position']),None)
  if not ph:raise ItemSkip(f'Provider no longer supports {cf["position"]} for variant {vid}')
  cf['width']=ph['width'];cf['height']=ph['height']
 return c,variants,config,desc

def payload(row,style,folder,label,slug,setup):
 c,vs,cfg,desc=setup;bp=c[0]['blueprint_id'];groups=defaultdict(list)
 for vid,cf in cfg.items():
  groups[(cf['position'],cf['decoration_method'],cf['scale'],cf['ink'])].append(vid)
 areas=[]
 for (pos,deco,scale,ink),vids in groups.items():
  path=ART/folder/aspect(bp)/f'{slug}-{ink}.png';iid=artid(path)
  # Check the actual ink bounds, not transparent canvas margins, against each print area.
  im=Image.open(path);bbox=im.getbbox();iw,ih=im.size;y=.32 if upper(row) else .5
  for vid in vids:
   cf=cfg[vid];ratio=cf['width']/cf['height'];left=.5+(bbox[0]/iw-.5)*scale;right=.5+(bbox[2]/iw-.5)*scale;top=y+(bbox[1]/iw-ih/iw/2)*scale*ratio;bottom=y+(bbox[3]/iw-ih/iw/2)*scale*ratio
   if min(left,top)<-.015 or max(right,bottom)>1.015:raise ItemSkip(f'Artwork ink would clip on {pos}, variant {vid}, source scale {scale}; not resized')
  ph={'position':pos,'images':[{'id':iid,'x':.5,'y':y,'scale':scale,'angle':0}]}
  if deco:ph['decoration_method']=deco
  areas.append({'variant_ids':vids,'placeholders':[ph]})
 body={'title':f'{row["product_name"]}: {label} ({style})','description':desc,'blueprint_id':bp,'print_provider_id':c[0]['print_provider_id'],'variants':list(vs.values()),'print_areas':areas,'visible':False}
 if c[0].get('print_details') and isinstance(c[0]['print_details'],dict):body['print_details']=c[0]['print_details']
 return body

def sample_sheet():
 entries=STATE['created'];chosen=[];seen=set()
 # Representative sampling spaced across the completed catalog, styles rotate.
 if not entries:return
 by=defaultdict(list)
 for d in entries:by[d['slug']].append(d)
 keys=list(by);stride=max(1,len(keys)//24)
 for i,k in enumerate(keys[::stride][:24]):chosen.append(by[k][i%len(by[k])])
 tiles=[];meta=[]
 for d in chosen:
  try:
   p=req('GET',f'/shops/{SHOP}/products/{d["product_id"]}.json')
   ims=p.get('images',[]);im=next((x for x in ims if x.get('is_default')),ims[0] if ims else None)
   if not im:continue
   r=requests.get(im['src'],timeout=90);r.raise_for_status();fp=W/'mockups'/f'{d["product_id"]}.jpg';fp.parent.mkdir(exist_ok=True);fp.write_bytes(r.content)
   tile=Image.new('RGB',(340,390),'white');pic=ImageOps.contain(Image.open(fp).convert('RGB'),(330,320));tile.paste(pic,((340-pic.width)//2,0));draw=ImageDraw.Draw(tile);text=d['title'];lines=[text[i:i+45] for i in range(0,len(text),45)];draw.multiline_text((6,325),'\n'.join(lines),fill='black');tiles.append(tile);meta.append({'title':d['title'],'id':d['product_id'],'path':str(fp)})
  except Exception as e:log('Sample mockup unavailable: '+str(e)[:200])
 if tiles:
  sheet=Image.new('RGB',(340*6,390*((len(tiles)+5)//6)), '#dedede')
  for i,t in enumerate(tiles):sheet.paste(t,((i%6)*340,(i//6)*390))
  sheet.save(W/'sample-sheet.png');save('sample-sheet.json',meta)

def main():
 global PRODUCTS,STATE
 lock=open(W/'run.lock','w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 prior=json.loads((W/'progress.json').read_text()) if (W/'progress.json').exists() else {}
 STATE=prior if 'uploads' in prior else {'started_at_ct':now(),'created':[],'existing':[],'skipped':[],'failures':[],'complete_items':[],'uploads':{}}
 STATE['status']='running';STATE.pop('finished_at_ct',None);checkpoint()
 log('Approved 195-item scope restored. New drafts only; existing sources and tests untouched.')
 PRODUCTS=all_products();save('shop-run-start.json',PRODUCTS)
 titles=defaultdict(list)
 for p in PRODUCTS:titles[p['title']].append(p)
 rows=[r for r in csv.DictReader(open(CSV)) if r['catalog_source']=='buyer-shop'];assert len(rows)==195
 save('scope.json',{'checked_at_ct':now(),'status':'approved_all_195','eligible':rows,'excluded':[],'note':'Old baked-in wordmark not an exclusion. Source images never copied. Three completed test items skipped; duplicate tote untouched.'})
 # Reuse exact uploaded art ids from approved test records, one upload per unique file.
 def seed(obj):
  if isinstance(obj,dict):
   for ink in ['light','dark']:
    f=obj.get(ink+'_file');iid=obj.get(ink+'_image_id')
    if f and iid and Path(f).is_file() and any('/'+folder+'/' in f for _,folder in STYLES):STATE['uploads'].setdefault(f,{'id':iid,'sha256':hashlib.sha256(Path(f).read_bytes()).hexdigest()})
   for v in obj.values():seed(v)
  elif isinstance(obj,list):
   for v in obj:seed(v)
 for fn in ['created-wordmark-test.json','created-wordmark-test-plates.json','created-wordmark-test-pop-v2.json']:seed(json.loads((W.parent/fn).read_text()))
 # Above historical Pop v1 ids must not be used: replace Pop roots from approved v2 records.
 v2=json.loads((W.parent/'created-wordmark-test-pop-v2.json').read_text())
 for d in v2['results']:
  for ink in ['light','dark']:
   f=d.get(ink+'_file');iid=d.get(ink+'_image_id')
   if f and iid:STATE['uploads'][f]={'id':iid,'sha256':hashlib.sha256(Path(f).read_bytes()).hexdigest()}
 checkpoint()
 done_titles={d['title'] for d in STATE['existing']+STATE['created']};skipped={d['slug'] for d in STATE['skipped']}
 for idx,row in enumerate(rows):
  key=row['slug'];bp=int(key.rsplit('-',1)[1]);log(f'ITEM {idx+1}/195 {key}')
  if key in STATE['complete_items'] or key in skipped:continue
  if bp in TEST:
   for style,folder in STYLES:
    for label,slug in MARKS:
     title=f'{row["product_name"]}: {label} ({style})';cs=titles.get(title,[])
     if not cs:raise HardStop('Expected approved test draft is missing: '+title)
     p=cs[0]
     if title not in done_titles:STATE['existing'].append({'slug':key,'title':title,'product_id':p['id'],'visible':p.get('visible'),'external':p.get('external')});done_titles.add(title)
   STATE['complete_items'].append(key);checkpoint();continue
  try:
   setup=plan(row)
   STATE.setdefault('source_setups',{})[key]={'ids':[p['id'] for p in setup[0]],'enabled_variants':len(setup[1]),'provider_id':setup[0][0]['print_provider_id']}
   # Preflight all styles/marks before creating any item products (fit, print area, art).
   bodies=[payload(row,style,folder,label,slug,setup) for style,folder in STYLES for label,slug in MARKS]
   for body in bodies:
    title=body['title'];cs=titles.get(title,[])
    if cs:
     match=next((p for p in cs if p['blueprint_id']==bp),None)
     if not match:raise ItemSkip('Title collision with another blueprint; required title is not unique: '+title)
     if title not in done_titles:STATE['existing'].append({'slug':key,'title':title,'product_id':match['id'],'visible':match.get('visible'),'external':match.get('external')});done_titles.add(title);checkpoint()
     continue
    try:p=req('POST',f'/shops/{SHOP}/products.json',body)
    except ItemSkip as e:
     STATE['failures'].append({'slug':key,'title':title,'reason':str(e)});checkpoint();raise ItemSkip('Creation rejected; remaining versions skipped: '+str(e))
    if p.get('visible') is not False or p.get('external') or p.get('is_locked'):raise HardStop('Unexpected publication/visibility state for new product '+p['id'])
    expected={i['id'] for a in body['print_areas'] for ph in a['placeholders'] for i in ph['images']};actual={i['id'] for a in p['print_areas'] for ph in a['placeholders'] for i in ph['images']}
    if not actual.issubset(expected) or not actual:raise HardStop('New product art verification mismatch '+p['id'])
    record={'slug':key,'title':title,'product_id':p['id'],'blueprint_id':bp,'visible':p['visible'],'external':p.get('external'),'only_new_art_verified':True}
    STATE['created'].append(record);titles[title].append(p);done_titles.add(title);checkpoint();log(f'CREATED {len(STATE["created"])} {p["id"]} {title}')
   STATE['complete_items'].append(key);checkpoint();log(f'CHECKPOINT {STATE["counts"]}')
  except ItemSkip as e:
   STATE['skipped'].append({'slug':key,'item':row['product_name'],'reason':str(e)});checkpoint();log('SKIPPED '+key+': '+str(e))
  if len(STATE['complete_items'])%25==0:sample_sheet()
 STATE['status']='completed_with_skips' if STATE['skipped'] else 'completed';STATE['finished_at_ct']=now();checkpoint();sample_sheet();save('summary.json',{'status':STATE['status'],'counts':STATE['counts'],'finished_at_ct':STATE['finished_at_ct'],'all_new_unpublished':all(d['visible'] is False and not d['external'] for d in STATE['created']),'skipped':STATE['skipped'],'failures':STATE['failures'],'duplicate_test_tote_untouched':['6af478373e4c8129d10bb756','6af4780d691bcc1a6f052a7a']});log('FINISHED '+str(STATE['counts']))

if __name__=='__main__':
 try:main()
 except Exception as e:
  log('HARD BLOCKER '+str(e));
  if 'STATE' in globals():STATE['status']='blocked';STATE['blocker']=str(e).replace(TOKEN,'[REDACTED]');checkpoint()
  raise
