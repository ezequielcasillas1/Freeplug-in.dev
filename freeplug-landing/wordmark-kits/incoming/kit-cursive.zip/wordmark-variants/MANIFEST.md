# Freeplug merch wordmark variants

Built 11 November 2026, America/Chicago. Cheke approved via Danissia, 3:02 AM CT, "Do it".
Print files only. Repo, Printify, and the site were not modified.

## Matched source style

Current plain-item print (the rectangular cursive wordmark used on baked buyer-shop / merch-store blanks):

- Shop overlays (identical MD5):
  - `/workspace/owen/golive-wt/freeplug-landing/public/merch/shop/freeplug-logo-light-garment.png`
  - `/workspace/owen/golive-wt/freeplug-landing/public/merch/shop/freeplug-logo-dark-garment.png`
  - Same files also live as `beanie-freeplug/front-embroidery-{light,dark}-garment.png`.
- Vector source: `/workspace/logos/freeplug/merch/beanie-freeplug/front-embroidery.svg`
  - Canvas **1500 × 525** (aspect 20:7).
  - Red rounded plate `#ba3d3d`, `rect x=45 y=60 width=1410 height=405 rx=35`.
  - Lettering is **FP Cursive Bold** (`/workspace/logos/freeplug/cursive/ttf/FPCursive-Bold.ttf`, version 2.000).
  - Glyphs are outlined paths (no live text), placed on **raw advance widths** (the font's F+r kern of −330 is not applied in the current print; these files match that construction).
  - Group transform `translate(130.648, 330.326) scale(0.258386, -0.258386)`.
  - `stroke-width` 69.663… font units (= **18 px** on the 1500 canvas), `stroke-linejoin=round`, `paint-order=stroke`, fill and stroke the same color.
  - Light garments: letter fill/stroke `#171717`. Dark garments: letter fill/stroke ivory `#f7f3ea`, plus a ~6 px ivory ring around the red plate.
  - Stroked "Freeplug" ink bbox (129.4, 111, 1370.6, 414); side padding 8.63%, vertical padding 21.14%. Recreated bounds match the PNG ink mask to 1 px.

The coming-soon-7 bracelet engraving (`1560 × 240`, FP Extended Black "FREEPLUG", no plate) is a different style used only on that engraving, not the current plain-item print.

`/workspace/logos/FP/USAGE.md` recommends Poppins SemiBold for the marketing wordmark. That was **not** used here: the current merch print is FP Cursive Bold, which was identifiable from the source SVG path advances (exact match to Bold metrics 936/585/521/521/631/393/572).

## What these files change

These are drop-in swaps of the **lettering construction** on the same 20:7 canvas:

- Same font, weight, stroke recipe, unkerned advances, and canvas aspect.
- Four text versions: `Freeplug.dev`, `FPLGN`, `Freeplug-in.dev`, `Freeplug.in`.
- Light-ink (ivory `#f7f3ea`) and dark-ink (`#171717`) of each.
- **No background plate.** The current red rounded rectangle is omitted on purpose: ink-on-red `#171717` on `#ba3d3d` is only 3.26:1, and the red plate itself is 4.11:1 on natural, 3.82:1 on black, and 2.00:1 on charcoal — all short of the 4.5:1 requirement. Lettering sits on a transparent canvas so contrast is against the garment. Composites on natural and charcoal show only the letters, no rectangle.
- One typographic size is shared across all four versions, fitted so the longest string (`Freeplug-in.dev`) has the same 8.63% side padding as the current "Freeplug" ink. Shorter marks are horizontally and vertically centered at that same size.

## Canvas ratios

- **Main (20:7)** — `4500 × 1575` px, 3× the current 1500 × 525 asset. Scale factor 0.45729524 (source was 0.2583862194016319). Files at the folder root.
- **Square (1:1)** — `4500 × 4500` px, same letter size as main, centered. Subfolder `square/`.
- **Portrait (3:4)** — `4500 × 6000` px, same letter size as main, centered. Subfolder `portrait/`.
- **Bar (6.5:1)** — `4500 × 692` px, scale 0.37767026 so the lettering fits ~8.6% x / ~18% y padding. Subfolder `bar/`.

## Mapping from PR #59 `wordmark-variants-list.csv`

The CSV (branch `cursor/wordmark-variants-1af7`) lists product / catalog / slug / URL / default wordmark / whether the mark is baked in Printify. It does **not** include print-area or aspect-ratio columns. Ratio groups below are inferred from the current 1500 × 525 shop-logo asset and from coming-soon-7 print-area specs.

- **Main 20:7** — use the root files. Covers the 267 plain SKUs where `wordmark_baked_in_printify=yes` (195 buyer-shop + most merch-store blanks). Those items currently use the 1500 × 525 red-plate wordmark as the placed print/overlay asset (shop placement: 1500 × 525, scale ~0.38, x=0.5, y=0.42). Beanie embroidery is the same 1500 × 525 asset. Dad-hat / low-profile embroidery canvases at 1650 × 600 (2.75:1) are close enough to 20:7 (2.857:1) that the main files can be placed without a separate master.

- **Square 1:1** — `square/`. For the three coming-soon items whose print area is 3000 × 3000:
  - `fanny-pack-468`
  - `glass-cutting-board-938`
  - `garden-house-banner-976` (art is portrait-safe in the center of a square; the portrait files can also be placed in that center column)

- **Portrait 3:4** — `portrait/`. For the three coming-soon items whose print area is 3600 × 4800:
  - `matte-canvas-stretched-0-75-multi-size-937`
  - `matte-canvas-stretched-1-25-1159`
  - `metal-art-sign-1206`

- **Bar 6.5:1** — `bar/`. For `natural-stone-stretch-bar-bracelet-engraving-2651` (print area 1560 × 240). Note: the live coming-soon-7 engraving is a different style (FP Extended Black "FREEPLUG", no cursive stroke). This bar set is the cursive family at the engraving aspect, provided so the four text versions exist at that ratio; it is not a reconstruction of the Extended Black engraving.

The 7 rows with `wordmark_baked_in_printify=no` are the swappable coming-soon items listed above. Designed (non-plain) catalog tees are out of scope.


## Contrast (WCAG relative luminance)

Threshold 4.5:1. Dark ink is checked against white and natural; light ink (ivory) against black and charcoal.

| Pair | Ratio | Result |
|---|---|---|
| dark ink #171717 vs white (255,255,255) | 17.93:1 | PASS |
| dark ink #171717 vs natural (232,222,200) | 13.41:1 | PASS |
| light ink ivory #f7f3ea vs black (0,0,0) | 18.96:1 | PASS |
| light ink ivory #f7f3ea vs charcoal (60,60,62) | 9.94:1 | PASS |
| (reference) dark ink #171717 vs red plate #ba3d3d | 3.26:1 | FAIL |
| (reference) ivory #f7f3ea vs red plate #ba3d3d | 4.96:1 | PASS |
| (reference) red plate #ba3d3d vs white | 5.49:1 | PASS |
| (reference) red plate #ba3d3d vs natural | 4.11:1 | FAIL |
| (reference) red plate #ba3d3d vs black | 3.82:1 | FAIL |
| (reference) red plate #ba3d3d vs charcoal | 2.00:1 | FAIL |

The current red plate is documented above for comparison; it is not used in these files.

## Files

Naming: `<slug>-<light|dark>.png` / `.svg`. `light` = ivory ink (dark items). `dark` = `#171717` ink (light items). SVGs have text converted to paths.

- `overview.png`
- `freeplug-dev-dark.png`
- `freeplug-dev-dark.svg`
- `freeplug-dev-light.png`
- `freeplug-dev-light.svg`
- `fplgn-dark.png`
- `fplgn-dark.svg`
- `fplgn-light.png`
- `fplgn-light.svg`
- `freeplug-in-dev-dark.png`
- `freeplug-in-dev-dark.svg`
- `freeplug-in-dev-light.png`
- `freeplug-in-dev-light.svg`
- `freeplug-in-dark.png`
- `freeplug-in-dark.svg`
- `freeplug-in-light.png`
- `freeplug-in-light.svg`
- `square/freeplug-dev-dark.png`
- `square/freeplug-dev-dark.svg`
- `square/freeplug-dev-light.png`
- `square/freeplug-dev-light.svg`
- `square/fplgn-dark.png`
- `square/fplgn-dark.svg`
- `square/fplgn-light.png`
- `square/fplgn-light.svg`
- `square/freeplug-in-dev-dark.png`
- `square/freeplug-in-dev-dark.svg`
- `square/freeplug-in-dev-light.png`
- `square/freeplug-in-dev-light.svg`
- `square/freeplug-in-dark.png`
- `square/freeplug-in-dark.svg`
- `square/freeplug-in-light.png`
- `square/freeplug-in-light.svg`
- `portrait/freeplug-dev-dark.png`
- `portrait/freeplug-dev-dark.svg`
- `portrait/freeplug-dev-light.png`
- `portrait/freeplug-dev-light.svg`
- `portrait/fplgn-dark.png`
- `portrait/fplgn-dark.svg`
- `portrait/fplgn-light.png`
- `portrait/fplgn-light.svg`
- `portrait/freeplug-in-dev-dark.png`
- `portrait/freeplug-in-dev-dark.svg`
- `portrait/freeplug-in-dev-light.png`
- `portrait/freeplug-in-dev-light.svg`
- `portrait/freeplug-in-dark.png`
- `portrait/freeplug-in-dark.svg`
- `portrait/freeplug-in-light.png`
- `portrait/freeplug-in-light.svg`
- `bar/freeplug-dev-dark.png`
- `bar/freeplug-dev-dark.svg`
- `bar/freeplug-dev-light.png`
- `bar/freeplug-dev-light.svg`
- `bar/fplgn-dark.png`
- `bar/fplgn-dark.svg`
- `bar/fplgn-light.png`
- `bar/fplgn-light.svg`
- `bar/freeplug-in-dev-dark.png`
- `bar/freeplug-in-dev-dark.svg`
- `bar/freeplug-in-dev-light.png`
- `bar/freeplug-in-dev-light.svg`
- `bar/freeplug-in-dark.png`
- `bar/freeplug-in-dark.svg`
- `bar/freeplug-in-light.png`
- `bar/freeplug-in-light.svg`

Overview: `overview.png` — all 4 versions × dark ink on white and natural, light ink on charcoal and black.

## Rebuild

```sh
python3 /workspace/logos/freeplug-merchandise/wordmark-variants/build_wordmark_variants.py
```

