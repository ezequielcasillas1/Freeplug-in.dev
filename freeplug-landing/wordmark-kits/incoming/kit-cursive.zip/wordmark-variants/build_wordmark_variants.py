#!/usr/bin/env python3
"""Build Freeplug merch wordmark variants.

Matches the current plain-item print construction (beanie / shop logo SVG):
FP Cursive Bold, unkerned advances, rounded stroke, paint-order stroke,
1500x525 canvas aspect. No plate / no background panel.
Pillow/SVG only. Does not modify the repo, Printify, or the site.
"""

from __future__ import annotations

import math
from pathlib import Path

import cairosvg
import numpy as np
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFont

ROOT = Path("/workspace/logos/freeplug-merchandise/wordmark-variants")
FONT_PATH = Path("/workspace/logos/freeplug/cursive/ttf/FPCursive-Bold.ttf")
LABEL_FONT = Path("/workspace/logos/FP/fonts/ttf/FreeplugDispatch-Regular.ttf")
SOURCE_SVG = Path(
    "/workspace/logos/freeplug/merch/beanie-freeplug/front-embroidery.svg"
)
SOURCE_LIGHT = Path(
    "/workspace/owen/golive-wt/freeplug-landing/public/merch/shop/"
    "freeplug-logo-light-garment.png"
)

# Source construction (1500 x 525 canvas)
SRC_W, SRC_H = 1500, 525
SRC_SCALE = 0.2583862194016319
SRC_TX, SRC_TY = 130.64823209428823, 330.3263825929284
SRC_STROKE = 69.66315789473684  # font units; 18 px on the 1500 canvas
# Side padding of the current "Freeplug" ink, from verified bbox math
SRC_INK = (129.3998186763372, 111.0, 1370.6001813236626, 414.0)
SRC_PAD_X = SRC_INK[0] / SRC_W  # ~0.086266

INK = (23, 23, 23)  # #171717 — matches current light-garment letter fill
IVORY = (247, 243, 234)  # #f7f3ea — matches current dark-garment letter fill
WHITE = (255, 255, 255)
NATURAL = (232, 222, 200)
CHARCOAL = (60, 60, 62)
BLACK = (0, 0, 0)

# Main ratio is exactly 3x the current 1500x525 print asset
MAIN_W, MAIN_H = 4500, 1575
SQUARE_W = SQUARE_H = 4500
PORTRAIT_W, PORTRAIT_H = 4500, 6000
BAR_W, BAR_H = 4500, 692  # 6.5:1 (1560x240 scaled)

VERSIONS = [
    ("freeplug-dev", "Freeplug.dev"),
    ("fplgn", "FPLGN"),
    ("freeplug-in-dev", "Freeplug-in.dev"),
    ("freeplug-in", "Freeplug.in"),
]

INK_VARIANTS = {
    "dark": INK,  # dark ink for light items
    "light": IVORY,  # light ink for dark items
}


def hex_of(rgb: tuple[int, int, int]) -> str:
    return "#{:02x}{:02x}{:02x}".format(*rgb)


def lin(c: float) -> float:
    c = c / 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def lum(rgb: tuple[int, int, int]) -> float:
    r, g, b = rgb
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)


def contrast(a: tuple[int, int, int], b: tuple[int, int, int]) -> float:
    l1, l2 = lum(a), lum(b)
    hi, lo = max(l1, l2), min(l1, l2)
    return (hi + 0.05) / (lo + 0.05)


class WordmarkFont:
    def __init__(self, path: Path):
        self.font = TTFont(str(path))
        self.gs = self.font.getGlyphSet()
        self.cmap = self.font.getBestCmap()
        self.upm = self.font["head"].unitsPerEm

    def glyphs(self, text: str):
        """Yield (char, glyph_name, glyph, x_offset) using raw advances, no kern.

        The current plain-item SVG places letters on raw advance widths
        (F+r kern of -330 is not applied). Match that construction.
        """
        x = 0
        for ch in text:
            name = self.cmap.get(ord(ch))
            if name is None:
                raise ValueError(f"Missing glyph for {ch!r} in FP Cursive Bold")
            glyph = self.gs[name]
            yield ch, name, glyph, x
            x += glyph.width
        # total advance is last x after loop; returned via helper

    def total_advance(self, text: str) -> int:
        return sum(self.gs[self.cmap[ord(ch)]].width for ch in text)

    def font_bounds(self, text: str):
        """Path bbox in font units (no stroke), plus advance."""
        minx = miny = 1e18
        maxx = maxy = -1e18
        x = 0
        paths = []
        for ch, name, glyph, xoff in self.glyphs(text):
            pen = BoundsPen(self.gs)
            glyph.draw(pen)
            if pen.bounds is None:
                raise ValueError(f"No contours for {ch!r}")
            a, b, c, d = pen.bounds
            minx = min(minx, xoff + a)
            miny = min(miny, b)
            maxx = max(maxx, xoff + c)
            maxy = max(maxy, d)
            svg_pen = SVGPathPen(self.gs)
            glyph.draw(svg_pen)
            paths.append((xoff, svg_pen.getCommands()))
            x = xoff + glyph.width
        return (minx, miny, maxx, maxy), paths, x

    def stroked_bounds(self, text: str, stroke: float = SRC_STROKE):
        (minx, miny, maxx, maxy), paths, adv = self.font_bounds(text)
        hs = stroke / 2.0
        return (minx - hs, miny - hs, maxx + hs, maxy + hs), paths, adv


WM = WordmarkFont(FONT_PATH)


def placement_for_canvas(
    text: str,
    canvas_w: int,
    canvas_h: int,
    scale: float,
) -> tuple[float, float, float]:
    """Return (tx, ty, scale) to center the stroked wordmark on the canvas."""
    (minx, miny, maxx, maxy), _, _ = WM.stroked_bounds(text)
    # canvas point of font (x,y): (tx + s*x, ty - s*y)
    content_w = (maxx - minx) * scale
    content_h = (maxy - miny) * scale
    # left edge of content at (canvas_w - content_w)/2
    # left edge = tx + scale*minx
    tx = (canvas_w - content_w) / 2.0 - scale * minx
    # top edge = ty - scale*maxy
    ty = (canvas_h - content_h) / 2.0 + scale * maxy
    return tx, ty, scale


def main_scale() -> float:
    """Scale so the longest string gets the same side padding as current 'Freeplug'."""
    longest = "Freeplug-in.dev"
    (minx, miny, maxx, maxy), _, _ = WM.stroked_bounds(longest)
    fu_w = maxx - minx
    target_w = MAIN_W * (1.0 - 2.0 * SRC_PAD_X)
    return target_w / fu_w


def bar_scale(main_s: float) -> float:
    """Fit every string (use longest + tallest needs) inside the 6.5:1 bar.

    Prefer the main typographic size if it fits; otherwise shrink to honor
    ~8.6% x padding and ~18% y padding (coming-soon-7 bracelet y margin).
    """
    pad_x = SRC_PAD_X
    pad_y = 0.18
    s = main_s
    for _, text in VERSIONS:
        (minx, miny, maxx, maxy), _, _ = WM.stroked_bounds(text)
        max_s_w = (BAR_W * (1.0 - 2.0 * pad_x)) / (maxx - minx)
        max_s_h = (BAR_H * (1.0 - 2.0 * pad_y)) / (maxy - miny)
        s = min(s, max_s_w, max_s_h)
    return s


def svg_for(text: str, color: tuple[int, int, int], canvas_w: int, canvas_h: int, scale: float) -> str:
    tx, ty, s = placement_for_canvas(text, canvas_w, canvas_h, scale)
    _, paths, _ = WM.font_bounds(text)
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{canvas_w}" height="{canvas_h}" '
        f'viewBox="0 0 {canvas_w} {canvas_h}">',
        f'<g fill="{hex_of(color)}" stroke="{hex_of(color)}" stroke-width="{SRC_STROKE}" '
        f'stroke-linejoin="round" stroke-linecap="round" paint-order="stroke" '
        f'transform="translate({tx},{ty}) scale({s},{-s})">',
    ]
    for xoff, d in paths:
        parts.append(f'<path transform="translate({xoff},0)" d="{d}"/>')
    parts.append("</g></svg>")
    return "\n".join(parts)


def write_svg_png(svg: str, svg_path: Path, png_path: Path, canvas_w: int, canvas_h: int):
    svg_path.write_text(svg, encoding="utf-8")
    cairosvg.svg2png(
        bytestring=svg.encode("utf-8"),
        write_to=str(png_path),
        output_width=canvas_w,
        output_height=canvas_h,
        background_color="rgba(0,0,0,0)",
    )
    im = Image.open(png_path).convert("RGBA")
    # Safety: canvas size
    if im.size != (canvas_w, canvas_h):
        raise RuntimeError(f"{png_path} is {im.size}, expected {(canvas_w, canvas_h)}")
    return im


def opaque_stats(im: Image.Image):
    arr = np.array(im)
    a = arr[:, :, 3]
    rgb = arr[:, :, :3]
    opa = a > 20
    n = int(opa.sum())
    if n == 0:
        return n, []
    # unique-ish colors (quantize slightly for AA)
    q = (rgb[opa] // 8) * 8
    # top colors
    # too many unique; report mean + whether any near-white/near-black panel
    return n, rgb[opa]


def panel_pixel_count(im: Image.Image, ink: tuple[int, int, int], tol: int = 36) -> dict:
    """Count opaque pixels that are neither ink (plus AA toward ink) nor transparent.

    A filled plate would show up as a large mass of a third color (e.g. red).
    """
    arr = np.array(im)
    a = arr[:, :, 3]
    rgb = arr[:, :, :3].astype(int)
    opa = a > 20
    dist = np.max(np.abs(rgb - np.array(ink)[None, None, :]), axis=2)
    # ink-like (includes AA fringes toward the ink)
    inkish = opa & (dist <= tol)
    other = opa & ~inkish
    # also flag near-white / near-black fills
    whiteish = other & (rgb[:, :, 0] >= 240) & (rgb[:, :, 1] >= 240) & (rgb[:, :, 2] >= 240)
    blackish = other & (rgb[:, :, 0] <= 30) & (rgb[:, :, 1] <= 30) & (rgb[:, :, 2] <= 30)
    # red-plate-like
    redish = other & (np.abs(rgb[:, :, 0] - 186) <= 40) & (np.abs(rgb[:, :, 1] - 61) <= 40) & (
        np.abs(rgb[:, :, 2] - 61) <= 40
    )
    return {
        "opaque": int(opa.sum()),
        "inkish": int(inkish.sum()),
        "other": int(other.sum()),
        "whiteish": int(whiteish.sum()),
        "blackish": int(blackish.sum()),
        "redish": int(redish.sum()),
        "bbox": Image.fromarray((opa * 255).astype("uint8")).getbbox(),
    }


def composite_on(im: Image.Image, bg: tuple[int, int, int]) -> Image.Image:
    out = Image.new("RGB", im.size, bg)
    out.paste(im, mask=im.split()[-1])
    return out


def load_label_font(size: int):
    if LABEL_FONT.exists():
        return ImageFont.truetype(str(LABEL_FONT), size=size)
    return ImageFont.load_default()


def build_overview(previews: dict, out_path: Path):
    """4 rows (versions) x 4 swatch columns (dark on white/natural, light on charcoal/black)."""
    # Use a readable preview width; scale main masters down.
    cell_w, cell_h = 1200, 420
    label_h = 0
    row_label_w = 360
    col_h = 80
    footer_h = 90
    cols = [
        ("dark ink on white", "dark", WHITE),
        ("dark ink on natural", "dark", NATURAL),
        ("light ink on charcoal", "light", CHARCOAL),
        ("light ink on black", "light", BLACK),
    ]
    pad = 24
    width = row_label_w + len(cols) * (cell_w + pad) + pad
    height = col_h + 16 + len(VERSIONS) * (cell_h + label_h + pad) + footer_h
    canvas = Image.new("RGB", (width, height), (248, 246, 240))
    draw = ImageDraw.Draw(canvas)
    title_font = load_label_font(42)
    small = load_label_font(32)
    tiny = load_label_font(26)

    # column headers
    x0 = row_label_w
    y = 12
    for i, (label, _, _) in enumerate(cols):
        cx = x0 + i * (cell_w + pad) + cell_w // 2
        # text length
        bbox = draw.textbbox((0, 0), label, font=small)
        tw = bbox[2] - bbox[0]
        draw.text((cx - tw // 2, y), label, fill=(30, 30, 32), font=small)

    y = col_h + 8
    for slug, text in VERSIONS:
        # row label
        draw.text((20, y + cell_h // 2 - 12), text, fill=(30, 30, 32), font=title_font)
        for i, (label, ink_key, bg) in enumerate(cols):
            im = previews[(slug, ink_key)]
            # scale to fit cell, keeping aspect
            iw, ih = im.size
            scale = min(cell_w / iw, cell_h / ih)
            nw, nh = max(1, int(iw * scale)), max(1, int(ih * scale))
            resized = im.resize((nw, nh), Image.Resampling.LANCZOS)
            cell = Image.new("RGB", (cell_w, cell_h), bg)
            # paste centered
            px = (cell_w - nw) // 2
            py = (cell_h - nh) // 2
            cell.paste(resized, (px, py), resized)
            cx = x0 + i * (cell_w + pad)
            canvas.paste(cell, (cx, y))
            # thin rule
            draw.rectangle([cx, y, cx + cell_w - 1, y + cell_h - 1], outline=(200, 196, 188))
        y += cell_h + label_h + pad - label_h  # keep tight; label already in row
        y += pad

    foot = (
        "FP Cursive Bold  ·  no plate  ·  ivory #f7f3ea / ink #171717  ·  "
        "main canvas 4500x1575 (20:7)"
    )
    fb = draw.textbbox((0, 0), foot, font=tiny)
    draw.text(((width - (fb[2] - fb[0])) // 2, height - 48), foot, fill=(90, 88, 84), font=tiny)
    canvas.save(out_path, "PNG")
    return canvas


def write_manifest(main_s: float, bar_s: float, contrast_rows: list, ratio_notes: str, paths: list):
    def row(a, b, label):
        c = contrast(a, b)
        flag = "PASS" if c >= 4.5 else "FAIL"
        return f"| {label} | {c:.2f}:1 | {flag} |"

    lines = []
    lines.append("# Freeplug merch wordmark variants")
    lines.append("")
    lines.append("Built 11 November 2026, America/Chicago. Cheke approved via Danissia, 3:02 AM CT, \"Do it\".")
    lines.append("Print files only. Repo, Printify, and the site were not modified.")
    lines.append("")
    lines.append("## Matched source style")
    lines.append("")
    lines.append("Current plain-item print (the rectangular cursive wordmark used on baked buyer-shop / merch-store blanks):")
    lines.append("")
    lines.append("- Shop overlays (identical MD5):")
    lines.append("  - `/workspace/owen/golive-wt/freeplug-landing/public/merch/shop/freeplug-logo-light-garment.png`")
    lines.append("  - `/workspace/owen/golive-wt/freeplug-landing/public/merch/shop/freeplug-logo-dark-garment.png`")
    lines.append("  - Same files also live as `beanie-freeplug/front-embroidery-{light,dark}-garment.png`.")
    lines.append("- Vector source: `/workspace/logos/freeplug/merch/beanie-freeplug/front-embroidery.svg`")
    lines.append("  - Canvas **1500 × 525** (aspect 20:7).")
    lines.append("  - Red rounded plate `#ba3d3d`, `rect x=45 y=60 width=1410 height=405 rx=35`.")
    lines.append("  - Lettering is **FP Cursive Bold** (`/workspace/logos/freeplug/cursive/ttf/FPCursive-Bold.ttf`, version 2.000).")
    lines.append("  - Glyphs are outlined paths (no live text), placed on **raw advance widths** (the font's F+r kern of −330 is not applied in the current print; these files match that construction).")
    lines.append("  - Group transform `translate(130.648, 330.326) scale(0.258386, -0.258386)`.")
    lines.append("  - `stroke-width` 69.663… font units (= **18 px** on the 1500 canvas), `stroke-linejoin=round`, `paint-order=stroke`, fill and stroke the same color.")
    lines.append("  - Light garments: letter fill/stroke `#171717`. Dark garments: letter fill/stroke ivory `#f7f3ea`, plus a ~6 px ivory ring around the red plate.")
    lines.append("  - Stroked \"Freeplug\" ink bbox (129.4, 111, 1370.6, 414); side padding 8.63%, vertical padding 21.14%. Recreated bounds match the PNG ink mask to 1 px.")
    lines.append("")
    lines.append("The coming-soon-7 bracelet engraving (`1560 × 240`, FP Extended Black \"FREEPLUG\", no plate) is a different style used only on that engraving, not the current plain-item print.")
    lines.append("")
    lines.append("`/workspace/logos/FP/USAGE.md` recommends Poppins SemiBold for the marketing wordmark. That was **not** used here: the current merch print is FP Cursive Bold, which was identifiable from the source SVG path advances (exact match to Bold metrics 936/585/521/521/631/393/572).")
    lines.append("")
    lines.append("## What these files change")
    lines.append("")
    lines.append("These are drop-in swaps of the **lettering construction** on the same 20:7 canvas:")
    lines.append("")
    lines.append("- Same font, weight, stroke recipe, unkerned advances, and canvas aspect.")
    lines.append("- Four text versions: `Freeplug.dev`, `FPLGN`, `Freeplug-in.dev`, `Freeplug.in`.")
    lines.append("- Light-ink (ivory `#f7f3ea`) and dark-ink (`#171717`) of each.")
    lines.append("- **No background plate.** The current red rounded rectangle is omitted on purpose: ink-on-red `#171717` on `#ba3d3d` is only 3.26:1, and the red plate itself is 4.11:1 on natural, 3.82:1 on black, and 2.00:1 on charcoal — all short of the 4.5:1 requirement. Lettering sits on a transparent canvas so contrast is against the garment. Composites on natural and charcoal show only the letters, no rectangle.")
    lines.append("- One typographic size is shared across all four versions, fitted so the longest string (`Freeplug-in.dev`) has the same 8.63% side padding as the current \"Freeplug\" ink. Shorter marks are horizontally and vertically centered at that same size.")
    lines.append("")
    lines.append("## Canvas ratios")
    lines.append("")
    lines.append(f"- **Main (20:7)** — `{MAIN_W} × {MAIN_H}` px, 3× the current 1500 × 525 asset. Scale factor {main_s:.8f} (source was {SRC_SCALE}). Files at the folder root.")
    lines.append(f"- **Square (1:1)** — `{SQUARE_W} × {SQUARE_H}` px, same letter size as main, centered. Subfolder `square/`.")
    lines.append(f"- **Portrait (3:4)** — `{PORTRAIT_W} × {PORTRAIT_H}` px, same letter size as main, centered. Subfolder `portrait/`.")
    lines.append(f"- **Bar (6.5:1)** — `{BAR_W} × {BAR_H}` px, scale {bar_s:.8f} so the lettering fits ~8.6% x / ~18% y padding. Subfolder `bar/`.")
    lines.append("")
    lines.append(ratio_notes)
    lines.append("")
    lines.append("## Contrast (WCAG relative luminance)")
    lines.append("")
    lines.append("Threshold 4.5:1. Dark ink is checked against white and natural; light ink (ivory) against black and charcoal.")
    lines.append("")
    lines.append("| Pair | Ratio | Result |")
    lines.append("|---|---|---|")
    lines.extend(contrast_rows)
    lines.append("")
    lines.append("The current red plate is documented above for comparison; it is not used in these files.")
    lines.append("")
    lines.append("## Files")
    lines.append("")
    lines.append("Naming: `<slug>-<light|dark>.png` / `.svg`. `light` = ivory ink (dark items). `dark` = `#171717` ink (light items). SVGs have text converted to paths.")
    lines.append("")
    for p in paths:
        lines.append(f"- `{p}`")
    lines.append("")
    lines.append("Overview: `overview.png` — all 4 versions × dark ink on white and natural, light ink on charcoal and black.")
    lines.append("")
    lines.append("## Rebuild")
    lines.append("")
    lines.append("```sh")
    lines.append("python3 /workspace/logos/freeplug-merchandise/wordmark-variants/build_wordmark_variants.py")
    lines.append("```")
    lines.append("")
    (ROOT / "MANIFEST.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    for sub in ("square", "portrait", "bar", "_proof"):
        (ROOT / sub).mkdir(exist_ok=True)

    main_s = main_scale()
    bar_s = bar_scale(main_s)

    # Report fit numbers
    print(f"main scale {main_s:.8f}  (source {SRC_SCALE:.8f}, ratio {main_s/SRC_SCALE:.4f})")
    print(f"bar scale  {bar_s:.8f}")
    for slug, text in VERSIONS:
        (minx, miny, maxx, maxy), _, _ = WM.stroked_bounds(text)
        w = (maxx - minx) * main_s
        h = (maxy - miny) * main_s
        print(f"  {text!r:22} main content {w:.1f}x{h:.1f}  "
              f"pad x {(MAIN_W-w)/2/MAIN_W*100:.2f}%  y {(MAIN_H-h)/2/MAIN_H*100:.2f}%")

    groups = [
        (ROOT, MAIN_W, MAIN_H, main_s, "main"),
        (ROOT / "square", SQUARE_W, SQUARE_H, main_s, "square"),
        (ROOT / "portrait", PORTRAIT_W, PORTRAIT_H, main_s, "portrait"),
        (ROOT / "bar", BAR_W, BAR_H, bar_s, "bar"),
    ]

    written = []
    previews = {}
    proof_rows = []

    for dest, cw, ch, scale, group_name in groups:
        for slug, text in VERSIONS:
            for ink_key, color in INK_VARIANTS.items():
                svg = svg_for(text, color, cw, ch, scale)
                svg_path = dest / f"{slug}-{ink_key}.svg"
                png_path = dest / f"{slug}-{ink_key}.png"
                im = write_svg_png(svg, svg_path, png_path, cw, ch)
                stats = panel_pixel_count(im, color)
                # composites for transparency proof (saved only for main, one sample set)
                if group_name == "main" and ink_key == "dark":
                    for bgname, bg in (("natural", NATURAL), ("charcoal", CHARCOAL), ("white", WHITE)):
                        composite_on(im, bg).save(ROOT / "_proof" / f"{slug}-{ink_key}-on-{bgname}.png")
                if group_name == "main" and ink_key == "light":
                    for bgname, bg in (("charcoal", CHARCOAL), ("black", BLACK), ("natural", NATURAL)):
                        composite_on(im, bg).save(ROOT / "_proof" / f"{slug}-{ink_key}-on-{bgname}.png")
                if group_name == "main":
                    previews[(slug, ink_key)] = im
                rel_png = png_path.relative_to(ROOT)
                rel_svg = svg_path.relative_to(ROOT)
                written.append(str(rel_png))
                written.append(str(rel_svg))
                proof_rows.append((group_name, slug, ink_key, stats, im.size))
                print(f"wrote {rel_png}  opaque={stats['opaque']} other={stats['other']} "
                      f"white={stats['whiteish']} black={stats['blackish']} red={stats['redish']} bbox={stats['bbox']}")
                if stats["redish"] or stats["whiteish"] or stats["other"] > stats["opaque"] * 0.02:
                    # AA can produce a few 'other' pixels; flag only if large
                    if stats["redish"] or stats["whiteish"] or stats["other"] > 5000:
                        print(f"  WARNING panel-like pixels in {rel_png}: {stats}")

    overview_path = ROOT / "overview.png"
    build_overview(previews, overview_path)
    written.insert(0, "overview.png")
    print(f"wrote overview {overview_path.stat().st_size} {overview_path}")

    contrast_rows = [
        f"| dark ink #171717 vs white (255,255,255) | {contrast(INK, WHITE):.2f}:1 | {'PASS' if contrast(INK, WHITE) >= 4.5 else 'FAIL'} |",
        f"| dark ink #171717 vs natural (232,222,200) | {contrast(INK, NATURAL):.2f}:1 | {'PASS' if contrast(INK, NATURAL) >= 4.5 else 'FAIL'} |",
        f"| light ink ivory #f7f3ea vs black (0,0,0) | {contrast(IVORY, BLACK):.2f}:1 | {'PASS' if contrast(IVORY, BLACK) >= 4.5 else 'FAIL'} |",
        f"| light ink ivory #f7f3ea vs charcoal (60,60,62) | {contrast(IVORY, CHARCOAL):.2f}:1 | {'PASS' if contrast(IVORY, CHARCOAL) >= 4.5 else 'FAIL'} |",
        f"| (reference) dark ink #171717 vs red plate #ba3d3d | {contrast(INK, (186,61,61)):.2f}:1 | {'PASS' if contrast(INK, (186,61,61)) >= 4.5 else 'FAIL'} |",
        f"| (reference) ivory #f7f3ea vs red plate #ba3d3d | {contrast(IVORY, (186,61,61)):.2f}:1 | {'PASS' if contrast(IVORY, (186,61,61)) >= 4.5 else 'FAIL'} |",
        f"| (reference) red plate #ba3d3d vs white | {contrast((186,61,61), WHITE):.2f}:1 | {'PASS' if contrast((186,61,61), WHITE) >= 4.5 else 'FAIL'} |",
        f"| (reference) red plate #ba3d3d vs natural | {contrast((186,61,61), NATURAL):.2f}:1 | {'PASS' if contrast((186,61,61), NATURAL) >= 4.5 else 'FAIL'} |",
        f"| (reference) red plate #ba3d3d vs black | {contrast((186,61,61), BLACK):.2f}:1 | {'PASS' if contrast((186,61,61), BLACK) >= 4.5 else 'FAIL'} |",
        f"| (reference) red plate #ba3d3d vs charcoal | {contrast((186,61,61), CHARCOAL):.2f}:1 | {'PASS' if contrast((186,61,61), CHARCOAL) >= 4.5 else 'FAIL'} |",
    ]

    ratio_notes = """## Mapping from PR #59 `wordmark-variants-list.csv`

The CSV (branch `cursor/wordmark-variants-1af7`) lists product / catalog / slug / URL / default wordmark / whether the mark is baked in Printify. It does **not** include print-area or aspect-ratio columns. Ratio groups below are inferred from the current 1500 × 525 shop-logo asset and from coming-soon-7 print-area specs.

- **Main 20:7** — use the root files. Covers the 267 plain SKUs where `wordmark_baked_in_printify=yes` (195 buyer-shop + most merch-store blanks). Those items currently use the 1500 × 525 red-plate wordmark as the placed print/overlay asset (shop placement: 1500 × 525, scale ~0.38, x=0.5, y=0.42). Beanie embroidery is the same 1500 × 525 asset. Dad-hat / low-profile embroidery canvases at 1650 × 600 (2.75:1) are close enough to 20:7 (2.857:1) that the main files can be placed without a separate master.

- **Square 1:1** — `square/`. For the three coming-soon items whose print area is 3000 × 3000:
  - `fanny-pack-468`
  - `glass-cutting-board-938`
  - `garden-house-banner-976` (art is portrait-safe in the center of a square; the portrait files can also be placed in that center column)

- **Portrait 3:4** — `portrait/`. For the three coming-soon items whose print area is 3600 × 4800:
  - `matte-canvas-stretched-0-75-multi-size-937`
  - `matte-canvas-stretched-1-25-1159`
  - `metal-art-sign-1206`

- **Bar 6.5:1** — `bar/`. For `natural-stone-stretch-bar-bracelet-engraving-2651` (print area 1560 × 240). Note: the live coming-soon-7 engraving is a different style (FP Extended Black \"FREEPLUG\", no cursive stroke). This bar set is the cursive family at the engraving aspect, provided so the four text versions exist at that ratio; it is not a reconstruction of the Extended Black engraving.

The 7 rows with `wordmark_baked_in_printify=no` are the swappable coming-soon items listed above. Designed (non-plain) catalog tees are out of scope.
"""

    write_manifest(main_s, bar_s, contrast_rows, ratio_notes, written)

    # Source-match proof: recreate "Freeplug" at original scale/placement (no plate)
    # and overlay against the current light-garment ink mask.
    proof_src_svg = svg_for_source_placement("Freeplug", INK)
    (ROOT / "_proof" / "source-recreate-freeplug.svg").write_text(proof_src_svg, encoding="utf-8")
    cairosvg.svg2png(
        bytestring=proof_src_svg.encode("utf-8"),
        write_to=str(ROOT / "_proof" / "source-recreate-freeplug.png"),
        output_width=SRC_W,
        output_height=SRC_H,
        background_color="rgba(0,0,0,0)",
    )
    make_source_overlay()
    print("done")


def svg_for_source_placement(text: str, color: tuple[int, int, int]) -> str:
    """Exact source transform, for construction proof only."""
    _, paths, _ = WM.font_bounds(text)
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{SRC_W}" height="{SRC_H}" viewBox="0 0 {SRC_W} {SRC_H}">',
        f'<g fill="{hex_of(color)}" stroke="{hex_of(color)}" stroke-width="{SRC_STROKE}" '
        f'stroke-linejoin="round" stroke-linecap="round" paint-order="stroke" '
        f'transform="translate({SRC_TX},{SRC_TY}) scale({SRC_SCALE},{-SRC_SCALE})">',
    ]
    for xoff, d in paths:
        parts.append(f'<path transform="translate({xoff},0)" d="{d}"/>')
    parts.append("</g></svg>")
    return "\n".join(parts)


def make_source_overlay():
    """Red = current logo ink, green = our recreation; yellow = match."""
    src = Image.open(SOURCE_LIGHT).convert("RGBA")
    ours = Image.open(ROOT / "_proof" / "source-recreate-freeplug.png").convert("RGBA")
    s = np.array(src)
    o = np.array(ours)
    # ink mask from source (not the red plate)
    rgb, a = s[:, :, :3], s[:, :, 3]
    inkish = (
        (np.abs(rgb[:, :, 0].astype(int) - 23) < 40)
        & (np.abs(rgb[:, :, 1].astype(int) - 23) < 40)
        & (np.abs(rgb[:, :, 2].astype(int) - 23) < 40)
        & (a > 20)
    )
    rec = o[:, :, 3] > 20
    H, W = inkish.shape
    ov = np.zeros((H, W, 3), dtype=np.uint8)
    ov[inkish, 0] = 255
    ov[rec, 1] = 255
    Image.fromarray(ov).save(ROOT / "_proof" / "source-match-overlay.png")
    inter = int((inkish & rec).sum())
    union = int((inkish | rec).sum())
    iou = inter / union if union else 0
    print(f"source-match IoU (ink vs recreation, no plate): {iou:.4f} inter={inter} union={union}")
    # also side-by-side on white
    white = Image.new("RGB", (SRC_W * 2, SRC_H + 40), (255, 255, 255))
    # source letters only
    letters = Image.new("RGBA", (SRC_W, SRC_H), (0, 0, 0, 0))
    arr = np.array(letters)
    arr[inkish, :3] = (23, 23, 23)
    arr[inkish, 3] = 255
    letters = Image.fromarray(arr)
    left = Image.new("RGB", (SRC_W, SRC_H), (255, 255, 255))
    left.paste(letters, mask=letters.split()[-1])
    right = Image.new("RGB", (SRC_W, SRC_H), (255, 255, 255))
    right.paste(ours, mask=ours.split()[-1])
    white.paste(left, (0, 40))
    white.paste(right, (SRC_W, 40))
    d = ImageDraw.Draw(white)
    f = load_label_font(20)
    d.text((20, 10), "Current print letters (plate removed)", fill=(30, 30, 32), font=f)
    d.text((SRC_W + 20, 10), "Recreation from FP Cursive Bold + 18px stroke", fill=(30, 30, 32), font=f)
    white.save(ROOT / "_proof" / "source-match-side-by-side.png")


if __name__ == "__main__":
    main()
